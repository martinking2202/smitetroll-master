<?php
	include('header.php');
	unset($_SESSION['customer_id']);
	unset($_SESSION['customer_credits']);
	redirect('customers.php');
?>