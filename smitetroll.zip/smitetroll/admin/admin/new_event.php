<?php
	include('header.php');
?>
		<div id="main">
<?php
			if(isset($_SESSION['customer_id'])) {
				$customer = new Customer($con);
				$customerDets = $customer->get_customer($_SESSION['customer_id']);
				$customerslug = $customerDets['slug'];
				$customerCredits = $customerDets['credits'];

				if($customerCredits > 0) {
					include('../customers/'.$customerslug.'/db-details.php');
					$customerConnection = new Connection($u, $p, $db);
					$customerCon = $customerConnection->connect();	

					if(isset($_POST['event_name'])){
						$useCredit = $customer->spend_credit($_SESSION['customer_id']);

						if($useCredit){
							$_SESSION['customer_credits']--;
							$subbed_customer = $customerslug;
							$subbed_event = $_POST['event_name'];

							include('../customers/'.$subbed_customer.'/db-details.php');

							$CustomerConnection = new Connection($u, $p, $db);
							$CustCon = $CustomerConnection->connect();

							$exception_chars = array('`', '¬', '!', '"', '£', '$', '%', '^', '&', '*', '(', ')', '-', '+', '=', '[', '{', ']', '}', ':', ';', '@', '\'', '#', '~', ',', '<', '.', '>', '?', '/', '\\', '|');
							$event_name = strtolower(str_replace(' ', '_', str_replace($exception_chars, '', $subbed_event)));

							$event = new Event($con, $subbed_customer, $event_name);

							$eventID = $event->setup_customer_db($CustCon, $subbed_customer, $event_name);
							$mainDBSetup = $event->setup_main_db($con, $subbed_customer, $event_name);

							redirect('../admin/events.php?updated=new&action=details');
						}
						else {
?>
							<h1>There was an error in creating this event. Please try again, or check your credits to ensure you have enough to create an event</h1>
<?php
						}
					}
?>
					<form id="form_new_event" class="normal_sub" action="" method="post" enctype="multipart/form-data">
					    <label for="event_name">Event URL:</label>
					    <span class="sub_label"><?php echo "http://$_SERVER[HTTP_HOST]";?>/events/</span><input type="text" name="event_name" id="event_name"/>
					    <input type="submit" value="Submit" name="submit">
					</form>
<?php
				}
				else {
?>
					<div>
						<h2>Out of Credits</h2>
						<p>Please top up on credits, and then create your event.</p>
						<a class="button" href="add_credits.php">Buy Credits</a>
					</div>
<?php
				}
			}
?>
		</div>
	</body>
</html>