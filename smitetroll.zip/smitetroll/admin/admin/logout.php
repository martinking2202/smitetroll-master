<?php
	include('header.php');
?>
		<div id="main">
<?php
			if(isset($_SESSION['user_id'])){
				unset($_SESSION['user_id']);
				unset($_SESSION['customer_id']);
				redirect('login.php');
			}
			else {
?>
				<form name="login" method="post" action="login.php">
					<input type="text" placeholder="Username" name="user_name"/>
					<input type="password" placeholder="Password" name="password"/>
					<input type="submit" value="Login"/>
				</form>
<?php
			}
?>
		</div>
	</body>
</html>