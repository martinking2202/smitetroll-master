<?php
	include('header.php');
?>
		<div id="main">
<?php
			if(isset($_SESSION['customer_id'])) {
				$today = date('Y-m-d');
				$customer = new Customer($con);
				$customerDets = $customer->get_customer($_SESSION['customer_id']);
				$customerslug = $customerDets['slug'];

				$customer_purchases = $customer->get_purchases($_SESSION['customer_id']);
				if($customer_purchases){
?>
					<table id="purchases">
						<thead>
							<tr>
								<th>Plan Type</th>
								<th>Credits Purchased</th>
								<th>Purchase Date</th>
								<th>Plan Start Date</th>
								<th>Plan End Date</th>
							</tr>
						</thead>
						<tbody>
<?php
							foreach($customer_purchases as $purchase){
?>
								<tr <?php if($purchase['plan_end_date'] > $today){echo 'class="active"';} elseif ($purchase['plan_end_date'] < $today && $purchase['plan_end_date'] !== '0000-00-00'){ echo 'class="expired"';}?>>
									<td><?php echo $purchase['plan_type'];?></td>
									<td><?php if($purchase['credits_purchased']){echo $purchase['credits_purchased'];}else{ echo 'Subscription';}?></td>
									<td><?php echo date('d/m/Y', strtotime($purchase['plan_purchase_date']));?></td>
									<td><?php if($purchase['plan_start_date'] !== '0000-00-00'){echo date('d/m/Y', strtotime($purchase['plan_start_date']));}else{echo 'Immediate Access';}?></td>
									<td><?php if($purchase['plan_end_date'] !== '0000-00-00'){echo date('d/m/Y', strtotime($purchase['plan_end_date']));} else {echo 'Immediate Access';}?></td>
								</tr>
<?php
							}
?>
						</tbody>
					</table>
<?php
				}
			}
?>
		</div>
	</body>
</html>