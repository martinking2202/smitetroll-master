<?php
	include('header.php');
?>
<!DOCTYPE html>
<html>
	<head>
		<meta charset="UTF-8" />
		<meta name="viewport" content="width=device-width" />
		<title></title>
		<link rel="stylesheet" type="text/css" href="../css/style.css" />
		<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>
		<script type="text/javascript" src="../js/js.js"></script>
	</head>
	<body>
		<header>
			
		</header>
		<div id="main">
			<form name="user" method="post" action="create_user.php">
				<input type="text" placeholder="Username" name="user_name"/>
				<input type="password" placeholder="Password" name="password"/>
				<input type="submit" value="Register"/>
			</form>
		</div>
	</body>
</html>