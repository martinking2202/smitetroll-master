<?php
	include('header.php');
		if(isset($_SESSION['customer_id'])) {
			$customer = new Customer($con);
			$customerDets = $customer->get_customer($_SESSION['customer_id']);
			$customerslug = $customerDets['slug'];
			$customerCredits = $customerDets['credits'];
				
			if(isset($_POST['credits']) && isset($_POST['type'])){
				$creds = $_POST['credits'];
				$type = $_POST['type'];
				$startDate = date('Y-m-d');
				$endDate = NULL;
				if($type !== 'Pay as you go') {
					$duration = $_POST['duration'];
					$startingPoint = $_POST['startdate'];

					if($startingPoint !== 'now'){
						$creds = 0;
						$startDate = date('Y-m-d', strtotime("+1 month", strtotime('first day of this month', strtotime($startDate))));
					}

					if($type === 'Monthly'){
						$duration--;
						if($duration === 0){
							$endDate = $startDate;
						}
						else {
							$endDate = date('Y-m-d', strtotime("+".$duration." months", strtotime('first day of this month', strtotime($startDate))));
						}
						if($startingPoint === 'extend'){
							echo 'extend<br/>';
							$today = date('Y-m-d');
							$latestDate = $today;
							$customer_purchases = $customer->get_purchases($_SESSION['customer_id']);
							if($customer_purchases){
								foreach($customer_purchases as $purchase){
									if($purchase['plan_end_date'] > $latestDate && $purchase['plan_type'] === $type)
										$latestDate = $purchase['plan_end_date'];
								}
							}
							echo $latestDate.'<br/>';
							$startDate = date('Y-m-d', strtotime("+1 month",strtotime($latestDate)));
							$endDate = date('Y-m-d', strtotime("+1 month",strtotime("+".$duration." months", strtotime('first day of this month', strtotime($latestDate)))));
							echo $endDate.'<br/>';
						}
					}	
					else if($type === 'Yearly' || $type === 'Enterprise: Bronze' || $type === 'Enterprise: Silver' || $type === 'Enterprise: Gold'){
						if($startingPoint === 'extend'){
							echo 'extend<br/>';
							$today = date('Y-m-d');
							$latestDate = $today;
							$customer_purchases = $customer->get_purchases($_SESSION['customer_id']);
							if($customer_purchases){
								foreach($customer_purchases as $purchase){
									if($purchase['plan_end_date'] > $latestDate && $purchase['plan_type'] === $type)
										$latestDate = $purchase['plan_end_date'];
								}
							}
							echo $latestDate.'<br/>';
							$startDate = date('Y-m-d', strtotime("+1 month",strtotime($latestDate)));
							$endDate = date('Y-m-d', strtotime("+".$duration." years", strtotime('first day of this month', strtotime($latestDate))));
							echo $endDate.'<br/>';
						}
						else {
							$endDate = date('Y-m-d', strtotime("-1 month", strtotime("+".$duration." years", strtotime('first day of this month', strtotime($startDate)))));
						}
					}
				}
				else {
					$startDate = NULL;
				}
				$customer->add_credits($_SESSION['customer_id'], $creds);
				$customer->add_credit_plan($_SESSION['customer_id'], $type, $creds, date('Y-m-d'), $startDate, $endDate);
				$newCreds = $customer->get_credits($_SESSION['customer_id']);
				$_SESSION['customer_credits'] = $newCreds;
			}
		}
?>
	</body>
</html>