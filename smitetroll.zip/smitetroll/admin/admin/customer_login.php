<?php
	include('header.php');

	if(isset($_POST['customer_id'])) {
		$subbed_customer = $_POST['customer_id'];

		$user = new User($con);

		$login = $user->login_customer($con, $_SESSION['user_id'], $subbed_customer);

		$customer = new Customer($con);

		if($login){
			$_SESSION['customer_id'] = $login;

			$customer_id = $customer->get_customer($login);
			$credits = $customer->get_credits($customer_id['id']);

			$_SESSION['customer_credits'] = $credits;

			redirect('events.php');
		}
		else {
			unset($_SESSION['customer_id']);
			unset($_SESSION['customer_credits']);
			redirect('customers.php');
		}
	}
?>