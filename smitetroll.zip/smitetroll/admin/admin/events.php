<?php
	include('header.php');
?>
		<div id="main">
<?php
			if(isset($_GET['updated'])){
				$updated_event = $_GET['updated'];
			}
			else {
				$updated_event = '0';
			}
			if(isset($_GET['action'])){
				$updated_action = $_GET['action'];
			}
			else {
				$updated_action = '';
			}

			if(isset($_SESSION['customer_id'])) {
				$customer = new Customer($con);
				$customerDets = $customer->get_customer($_SESSION['customer_id']);
				$customerslug = $customerDets['slug'];

				include('../customers/'.$customerslug.'/db-details.php');
				$customerConnection = new Connection($u, $p, $db);
				$customerCon = $customerConnection->connect();	

				$customer_events = $customer->get_events($customerCon);

				if($customer_events){
?>
					<div id="events">
<?php
						foreach($customer_events as $event){
?>
							<div class="event<?php if($updated_event === $event['id']) echo ' updated';?>">
								<h3>
<?php 
									echo $event['name'];
?>
								</h3>
								<div class="actions">
									<div class="action<?php if($updated_event === $event['id'] && $updated_action === 'details') echo ' updated';?>">
										<a href="../events/<?php echo $event['name'];?>/details"/>Details</a>
									</div>
									<div class="action<?php if($updated_event === $event['id'] && $updated_action === 'customise') echo ' updated';?>">
										<a href="../events/<?php echo $event['name'];?>/customise"/>Customise</a>
									</div>
									<div class="action<?php if($updated_event === $event['id'] && $updated_action === 'logo') echo ' updated';?>">
										<a href="../events/<?php echo $event['name'];?>/upload"/>Logo Upload</a>
									</div>
									<div class="action">
										<a href="../events/<?php echo $event['name'];?>/form"/>Form</a>
									</div>
									<div class="action">
										<a href="../events/<?php echo $event['name'];?>"/>View</a>
									</div>
								</div>
							</div>
<?php
						}
?>
						<div class="new event<?php if($updated_event === "new") echo ' updated';?>">
							<h3>New</h3>
							<div class="actions">
								<div class="action">
									<a href="new_event"/>Create New Event</a>
								</div>
							</div>
						</div>
					</div>
<?php
				}
			}
?>
		</div>
	</body>
</html>