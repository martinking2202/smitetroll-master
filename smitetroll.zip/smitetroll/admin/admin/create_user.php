<?php
	include('../functions.php');
	include('../db-details.php');
	$connection = new Connection($u, $p, $db);
	$con = $connection->connect();
	$subbed_username = $_POST['user_name'];

	$exception_chars = array('`', '¬', '!', '"', '£', '$', '%', '^', '&', '*', '(', ')', '-', '+', '=', '[', '{', ']', '}', ':', ';', '@', '\'', '#', '~', ',', '<', '.', '>', '?', '/', '\\', '|');
	$subbed_username = strtolower(str_replace(' ', '_', str_replace($exception_chars, '', $subbed_username)));
	$user = new User($con);

	$userCreate = $user->create_user($con, $subbed_username, $_POST['password']);
?>