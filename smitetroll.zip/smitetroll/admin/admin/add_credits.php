<?php
	include('header.php');
?>
	<script type="text/javascript">
		function outputUpdate(vol, selector) {
			document.querySelector(selector).value = vol;
		}
	</script>
		<div id="main">
<?php
			if(isset($_SESSION['customer_id'])) {
				$customer = new Customer($con);
				$customerDets = $customer->get_customer($_SESSION['customer_id']);
				$customerslug = $customerDets['slug'];
				$customerCredits = $customerDets['credits'];

				$effectiveDate = date('Y-m-d');
				$endDate = date('d/m/Y', strtotime("+1 month", strtotime('first day of this month', strtotime($effectiveDate))));

				$customer_purchases = $customer->get_purchases($_SESSION['customer_id']);
				$extendOptionMonthly = false;
				$extendOptionYearly = false;
				$extendOptionEntBronze = false;
				$extendOptionEntSilver = false;
				$extendOptionEntGold = false;
				$today = date('Y-m-d');
				if($customer_purchases){
					foreach($customer_purchases as $purchase){
						if($purchase['plan_end_date'] > $today){
							if(strpos($purchase['plan_type'], 'prise')){
								$level = substr($purchase['plan_type'], strpos($purchase['plan_type'], ' ')+1);
								${'extendOptionEnt'.$level} = true;
							}
							else {
								${'extendOption'.$purchase['plan_type']} = true;
							}
						}
					}
				}				
?>
				<h2>You currently have <?php if($_SESSION['customer_credits']){echo $_SESSION['customer_credits'];}else{echo 0;}?> credits</h2>
				<h3>If you would like to add more credits, please select an option below:</h3>
				<div class="credit_row">
					<div class="credit_option single">
						<form id="form_add_credit_payg" class="normal_sub" action="add_credit.php" method="post" enctype="multipart/form-data">
						    <h3>Pay as you go:</h3>
						    <p>Please select the amount of credits that you would like to purchase</p>

						    <label for="credits">Credits</label>
							<input type="range" min="1" max="25" value="1" id="credits" name="credits" step="1" oninput="outputUpdate(value, '#credits_selected')">
							<output for="credits" id="credits_selected">1</output>

						    <input type="submit" value="Submit" name="submit">

						    <input type="hidden" name="type" value="Pay as you go"/>
						</form>
					</div>
				</div>
				<div class="credit_row">
					<div class="credit_row_container_8">
						<div class="credit_option half">
							<form id="form_add_credit_month" class="normal_sub" action="add_credit.php" method="post" enctype="multipart/form-data">
							    <h3>Monthly</h3>
							    <p>A Monthly subscription. Allows for 1 event to be created each month, where 1 credit is added at the start of each month (and immediately after this purchase).</p>
						    	<div class="field">
								    <label for="duration">Plan duration</label>
									<input type="range" min="1" max="24" value="1" id="duration" name="duration" step="1" oninput="outputUpdate(value, '#month_months')">
									<output for="duration" id="month_months">1</output>
								</div>
								<div class="field">
									<label for="startdate">When should this plan begin?</label>
									<div class="option">
										<input type="radio" value="now" name="startdate"> Immediately
									</div>
									<div class="option">
										<input type="radio" value="next" name="startdate"> Next month (<?php echo $endDate;?>)
									</div>
<?php
									if($extendOptionMonthly){
?>
										<div class="option">
											<input type="radio" value="extend" name="startdate"> Extend current plan
										</div>
<?php
									}
?>
								</div>
							    <input type="submit" value="Submit" name="submit">

							    <input type="hidden" name="credits" value="1"/>
							    <input type="hidden" name="type" value="Monthly"/>
							</form>
						</div>
						<div class="credit_option half">
							<form id="form_add_credit_year" class="normal_sub" action="add_credit.php" method="post" enctype="multipart/form-data">
							    <h3>Yearly</h3>
							    <p>A Yearly subscription. Allows for 1 event to be created each month, where 1 credit is added at the start of each month (and immediately after this purchase).</p>
						    	<div class="field">
								    <label for="duration">Plan Duration</label>
									<input type="range" min="1" max="5" value="1" id="duration" name="duration" step="1" oninput="outputUpdate(value, '#year_years')">
									<output for="duration" id="year_years">1</output>
								</div>
								<div class="field">
									<label for="startdate">When should this plan begin?</label>
									<div class="option">
										<input type="radio" value="now" name="startdate"> Immediately
									</div>
									<div class="option">
										<input type="radio" value="next" name="startdate"> Next Month (<?php echo $endDate;?>)
									</div>
<?php
									if($extendOptionYearly){
?>
										<div class="option">
											<input type="radio" value="extend" name="startdate"> Extend current plan
										</div>
<?php
									}
?>
								</div>
							    <input type="submit" value="Submit" name="submit">
							    
							    <input type="hidden" name="credits" value="1"/>
							    <input type="hidden" name="type" value="Yearly"/>
							</form>
						</div>
					</div>
				</div>
				<div class="credit_row">
					<div class="credit_option third">
						<form id="form_add_credit_ent_bronze" class="normal_sub" action="add_credit.php" method="post" enctype="multipart/form-data">
						    <h3>Enterprise: Bronze</h3>
						    <p>A Yearly subscription. Allows for 2 events to be created each month, where 2 credits are added at the start of each month (and immediately after this purchase).</p>
						    <div class="field">
							    <label for="duration">Plan Duration</label>
								<input type="range" min="1" max="5" value="1" id="duration" name="duration" step="1" oninput="outputUpdate(value, '#ent_bron_years')">
								<output for="duration" id="ent_bron_years">1</output>
							</div>
								<div class="field">
									<label for="startdate">When should this plan begin?</label>
									<div class="option">
										<input type="radio" value="now" name="startdate"> Immediately
									</div>
									<div class="option">
										<input type="radio" value="next" name="startdate"> Next Month (<?php echo $endDate;?>)
									</div>
<?php
									if($extendOptionEntBronze){
?>
										<div class="option">
											<input type="radio" value="extend" name="startdate"> Extend current plan
										</div>
<?php
									}
?>
								</div>
						    <input type="submit" value="Submit" name="submit">
						    
						    <input type="hidden" name="credits" value="2"/>
						    <input type="hidden" name="type" value="Enterprise: Bronze"/>
						</form>
					</div>
					<div class="credit_option third">
						<form id="form_add_credit_ent_silver" class="normal_sub" action="add_credit.php" method="post" enctype="multipart/form-data">
						    <h3>Enterprise: Silver</h3>
						    <p>A Yearly subscription. Allows for 5 events to be created each month, where 5 credits are added at the start of each month (and immediately after this purchase).</p>
						    <div class="field">
							    <label for="duration">Plan Duration</label>
								<input type="range" min="1" max="5" value="1" id="duration" name="duration" step="1" oninput="outputUpdate(value, '#ent_silv_years')">
								<output for="duration" id="ent_silv_years">1</output>
							</div>
								<div class="field">
									<label for="startdate">When should this plan begin?</label>
									<div class="option">
										<input type="radio" value="now" name="startdate"> Immediately
									</div>
									<div class="option">
										<input type="radio" value="next" name="startdate"> Next Month (<?php echo $endDate;?>)
									</div>
<?php
									if($extendOptionEntSilver){
?>
										<div class="option">
											<input type="radio" value="extend" name="startdate"> Extend current plan
										</div>
<?php
									}
?>
								</div>
						    <input type="submit" value="Submit" name="submit">
						    
						    <input type="hidden" name="credits" value="5"/>
						    <input type="hidden" name="type" value="Enterprise: Silver"/>
						</form>
					</div>
					<div class="credit_option third">
						<form id="form_add_credit_ent_gold" class="normal_sub" action="add_credit.php" method="post" enctype="multipart/form-data">
						    <h3>Enterprise: Gold</h3>
						    <p>A Yearly subscription. Allows for unlimited events to be created.</p>
						    <div class="field">
							    <label for="duration">Plan Duration</label>
								<input type="range" min="1" max="5" value="1" id="duration" name="duration" step="1" oninput="outputUpdate(value, '#ent_gold_years')">
								<output for="duration" id="ent_gold_years">1</output>
							</div>
								<div class="field">
									<label for="startdate">When should this plan begin?</label>
									<div class="option">
										<input type="radio" value="now" name="startdate"> Immediately
									</div>
									<div class="option">
										<input type="radio" value="next" name="startdate"> Next Month (<?php echo $endDate;?>)
									</div>
<?php
									if($extendOptionEntGold){
?>
										<div class="option">
											<input type="radio" value="extend" name="startdate"> Extend current plan
										</div>
<?php
									}
?>
								</div>
						    <input type="submit" value="Submit" name="submit">
						    
						    <input type="hidden" name="credits" value="inf"/>
						    <input type="hidden" name="type" value="Enterprise: Gold"/>
						</form>
					</div>
				</div>
<?php
			}
?>
		</div>
	</body>
</html>