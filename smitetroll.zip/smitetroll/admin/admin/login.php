<?php
	include('header.php');
?>

		<div id="main">
<?php
			if(isset($_POST['user_name']) && isset($_POST['password'])) {
				$subbed_username = $_POST['user_name'];
				$subbed_password = $_POST['password'];

				$user = new User($con);

				$login = $user->login($con, $subbed_username, $subbed_password);

				if($login){
					$_SESSION['user_id'] = $login;
					redirect('customers.php');
				}
				else {
					unset($_SESSION['user_id']);
					redirect('login.php');
				}
			}
			else {
?>
				<form name="login" method="post" action="login.php">
					<input type="text" placeholder="Username" name="user_name"/>
					<input type="password" placeholder="Password" name="password"/>
					<input type="submit" value="Login"/>
				</form>
<?php
			}
?>
		</div>
	</body>
</html>