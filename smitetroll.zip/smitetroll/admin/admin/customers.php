<?php
	include('header.php');
?>
		<div id="main">
<?php
			if(isset($_SESSION['user_id'])) {
				$user = new User($con, $_SESSION['user_id']);
				$user_customers = $user->get_customers($con, $_SESSION['user_id']);

				if($user_customers){
?>
					<div id="customers">
<?php
						foreach($user_customers as $customer){
?>
							<div class="customer<?php if(isset($_SESSION['customer_id']) && $customer['id'] === $_SESSION['customer_id']) echo ' active';?>">
								<h3>
<?php 
									echo $customer['name'];
?>
								</h3>
								<div class="actions">
<?php
									if(!isset($_SESSION['customer_id']) || $customer['id'] !== $_SESSION['customer_id']) {
?>
										<form name="customer_login" method="post" action="customer_login.php">
											<input type="hidden" name="customer_id" value="<?php echo $customer['id'];?>"/>
											<input type="submit" value="Login"/>
										</form>
<?php
									}
									else if(isset($_SESSION['customer_id']) && $customer['id'] === $_SESSION['customer_id']) {
?>
										<form name="customer_logout" method="post" action="customer_logout.php">
											<input type="submit" value="Logout"/>
										</form>
<?php
									}
?>
								</div>
							</div>
<?php
						}
?>
					</div>
<?php
				}
			}
?>
		</div>
	</body>
</html>