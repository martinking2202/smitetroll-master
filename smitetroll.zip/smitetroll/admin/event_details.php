<?php
	include('functions.php');
	include('db-details.php');
	$connection = new Connection($u, $p, $db);
    $mainCon = $connection->connect();

    $customer = new Customer($mainCon);
    $customerslug = $customer->get_customer_from_event($_GET['event_name']);

    include('customers/'.$customerslug.'/db-details.php');
    $CustomerConnection = new Connection($u, $p, $db);
    $con = $CustomerConnection->connect();

    $currentEvent = new Event($mainCon, $customerslug, $_GET['event_name']);
    $installation_id = $currentEvent->get_installation_id($con, $_GET['event_name']);

    if(isset($_POST['event_additional_area']) && $_POST['event_additional_area']) $currentEvent->add_event_system_option($con, $customerslug, 'event_additional_area', $_POST['event_additional_area'], $installation_id);
    if(isset($_POST['event_charity_name']) && $_POST['event_charity_name']) $currentEvent->add_event_system_option($con, $customerslug, 'event_charity_name', $_POST['event_charity_name'], $installation_id);
    if(isset($_POST['event_charity_address']) && $_POST['event_charity_address']) $currentEvent->add_event_system_option($con, $customerslug, 'event_charity_address', $_POST['event_charity_address'], $installation_id);
    if(isset($_POST['event_website']) && $_POST['event_website']) $currentEvent->add_event_system_option($con, $customerslug, 'event_website', $_POST['event_website'], $installation_id);
    if(isset($_POST['event_email']) && $_POST['event_email']) $currentEvent->add_event_system_option($con, $customerslug, 'event_email', $_POST['event_email'], $installation_id);
    if(isset($_POST['event_charity_no']) && $_POST['event_charity_no']) $currentEvent->add_event_system_option($con, $customerslug, 'event_charity_no', $_POST['event_charity_no'], $installation_id);
    if(isset($_POST['event_password']) && $_POST['event_password']) $currentEvent->add_event_system_option($con, $customerslug, 'event_password', $_POST['event_password'], $installation_id);
    if(isset($_POST['event_password']) || isset($_POST['event_charity_no']) || isset($_POST['event_email']) || isset($_POST['event_website']) || isset($_POST['event_charity_address']) || isset($_POST['event_charity_name']) || isset($_POST['event_additional_area']))
    	redirect('../../admin/events.php?updated='.$installation_id.'&action=details');
?>
<!DOCTYPE html>
<html>
	<head>
		<meta charset="UTF-8" />
		<meta name="viewport" content="width=device-width" />
		<title></title>
<?php
		include_once('pfr_base/css/style.php');
?>
		<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>
<?php
		include_once('pfr_base/js/js.php');
?>
	</head>
	<body>
		<header>
			
		</header>
		<div id="main">
			<form id="form_customise" class="normal_sub" action="" method="post" enctype="multipart/form-data">
			    <label for="event_additional_area">Middle Area Content</label>
			    <textarea name="event_additional_area" id="event_additional_area"></textarea>
			    <label for="event_charity_name">Charity Name</label>
			    <input type="text" name="event_charity_name" id="event_charity_name"/>
			    <label for="event_charity_address">Charity Address</label>
			    <textarea name="event_charity_address" id="event_charity_address"></textarea>
			    <label for="event_website">Charity Website</label>
			    <input type="text" name="event_website" id="event_website"/>
			    <label for="event_email">Charity Email</label>
			    <input type="text" name="event_email" id="event_email"/>
			    <label for="event_charity_no">Charity Number</label>
			    <input type="text" name="event_charity_no" id="event_charity_no"/>
			    <label for="event_password">Event Password</label>
			    <input type="text" name="event_password" id="event_password"/>
			    <input type="submit" value="Submit Customisations" name="submit">
			</form>
		</div>
	</body>
</html>