<?php
	include('functions.php');
	include('db-details.php');
	$connection = new Connection($u, $p, $db);
	$con = $connection->connect();
	$subbed_customer = $_POST['customer_name'];
	$exception_chars = array('`', '¬', '!', '"', '£', '$', '%', '^', '&', '*', '(', ')', '-', '+', '=', '[', '{', ']', '}', ':', ';', '@', '\'', '#', '~', ',', '<', '.', '>', '?', '/', '\\', '|');
	$customer_name = strtolower(str_replace(' ', '_', str_replace($exception_chars, '', $subbed_customer)));
	$customer = new Customer($con, $customer_name);

	$customer_in_main_db = $customer->setup_customer($subbed_customer, $customer_name);
	$customer_pw = $customer->create_db($customer_name);
	$customer_file = $customer->create_file_structure($customer_name, $customer_pw);
	echo '
		<input type="hidden" name="customer_name" value="'.$customer_name.'"/>
		<input type="hidden" name="customer_id" value="'.$customer_in_main_db.'"/>
	';
?>