function resizeHeight(element){
    var maxHeight = 0;
    jQuery(element).each(function(){
        var height = jQuery(this).height();
        if(height > maxHeight) maxHeight = height;
    });
    jQuery(element).each(function(){
        jQuery(this).height(maxHeight);
    });
}

jQuery(document).ready(function(){
    jQuery(document).on('click', 'form[name="customer"] input[type="submit"]', function(e){
        e.preventDefault();
        var customer_name = jQuery(this).parents('form').find('input[name="customer_name"]').val();
        jQuery.ajax({
            type: "POST",
            url: 'create_db.php',
            data:{customer_name: customer_name},
            timeout: 30000,
            error: function(request,error) {
                console.log(error);
            },
            success: function(data) {
                console.log(data);
                jQuery('form[name="event"]').removeClass('disabled');
                jQuery('form[name="event"]').append(data);
            }
        });
    });
    jQuery(document).on('click', 'form[name="event"] input[type="submit"]', function(e){
        e.preventDefault();
        var event_name = jQuery(this).parents('form').find('input[name="event_name"]').val();
        var customer_name = jQuery(this).parents('form').find('input[name="customer_name"]').val();
        var customer = jQuery(this).parents('form').find('input[name="customer"]').val();
        jQuery.ajax({
            type: "POST",
            url: 'create_event.php',
            data:{event_name: event_name, customer_name: customer_name},
            timeout: 5000,
            error: function(request,error) {
                console.log(error);
            },
            success: function(data) {
                console.log(data);
            }
        });
    });

    resizeHeight('.credit_option.half');
    resizeHeight('.credit_option.half p');
    resizeHeight('.credit_option.third');
    resizeHeight('.credit_option.third p');
});