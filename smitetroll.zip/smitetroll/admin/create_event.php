<?php
	include('functions.php');

	include('db-details.php');
	$mainConnection = new Connection($u, $p, $db);
	$MainCon = $mainConnection->connect();

	$subbed_customer = $_POST['customer_name'];
	$subbed_event = $_POST['event_name'];

	include('customers/'.$subbed_customer.'/db-details.php');

	$CustomerConnection = new Connection($u, $p, $db);
	$CustCon = $CustomerConnection->connect();

	$exception_chars = array('`', '¬', '!', '"', '£', '$', '%', '^', '&', '*', '(', ')', '-', '+', '=', '[', '{', ']', '}', ':', ';', '@', '\'', '#', '~', ',', '<', '.', '>', '?', '/', '\\', '|');
	$event_name = strtolower(str_replace(' ', '_', str_replace($exception_chars, '', $subbed_event)));

	$event = new Event($MainCon, $subbed_customer, $event_name);

	$eventID = $event->setup_customer_db($CustCon, $subbed_customer, $event_name);
	$mainDBSetup = $event->setup_main_db($MainCon, $subbed_customer, $event_name);

	echo $mainDBSetup;
	//$eventSetupFiles = $event->create_file_structure($subbed_customer, $event_name);
?>