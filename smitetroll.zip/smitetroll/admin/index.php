<?php
	include('functions.php');
	include('db-details.php');
	$connection = new Connection($u, $p, $db);
	$con = $connection->connect();
?>
<!DOCTYPE html>
<html>
	<head>
		<meta charset="UTF-8" />
		<meta name="viewport" content="width=device-width" />
		<title></title>
		<link rel="stylesheet" type="text/css" href="css/style.css" />
		<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>
		<script type="text/javascript" src="js/js.js"></script>
	</head>
	<body>
		<header>
			
		</header>
		<div id="main">
			<form name="customer" method="post" action="create_db.php">
				<input type="text" placeholder="Customer Name" name="customer_name"/>
				<input type="submit" value="Create Customer"/>
			</form>
			<form name="event" method="post" action="create_event.php">
				<input type="text" placeholder="Event Name" name="event_name"/>
				<input type="submit" value="Create Event for Customer"/>
				<input type="hidden" value="" name="customer"/>
			</form>
		</div>
	</body>
</html>