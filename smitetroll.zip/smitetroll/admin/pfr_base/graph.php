<?php	
	include('header.php');
	if($getEarliest = mysqli_query($con, "SELECT * FROM donations ORDER BY donation_id ASC LIMIT 1")) {
		$row = mysqli_fetch_assoc($getEarliest);		        
		$earliestTime = $row['donation_time'];
	}
	if($getLatest= mysqli_query($con, "SELECT * FROM donations ORDER BY donation_id DESC LIMIT 1")) {
		$row = mysqli_fetch_assoc($getLatest);		        
		$latestTime = $row['donation_time'];
	}
	if($get_event_target = mysqli_query($con, "SELECT * FROM system WHERE option_name = 'event_target';")) {
		$row = mysqli_fetch_assoc($get_event_target);		        
		$event_target = $row['option_value'];
	}
?>
		</header>
		<div id="graphContainer">
			<div id="target" class="label"><?php echo $event_target;?></div>
			<label id="targetComplete">Target</label>

			<div id="highestAmount" class="label">1000.00</div>
			<label id="amountDonated">Amount Donated</label>
			<div id="lowestAmount" class="label">0</div>

			<div id="timeEarliest" class="label"><?php echo $earliestTime;?></div>
			<label id="timeDonations">Time of Donations</label>
			<div id="timeLatest" class="label"><?php echo $latestTime;?></div>

			<div id="graph">
<?php
				if($getDonations = mysqli_query($con, "SELECT * FROM donations ORDER BY donation_id ASC LIMIT 1")) {
					$row = mysqli_fetch_assoc($getEarliest);		        
					$earliestTime = $row['donation_time'];
				}
?>
			</div>
			<canvas id="linegraph"></canvas>
		</div>
	</body>
</html>