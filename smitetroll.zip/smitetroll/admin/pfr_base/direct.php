<?php	
	include('header.php');
?>
	</header>
	<div id="content" class="main_view">
		<div id="new_donor">
			<h2>New Donor</h2>
			<div class="field">
				<input type="submit" value="Submit" name="submit_new"/>
			</div>
			<div class="field">
				<input name="donor_f_name" type="text" placeholder="F Name"/>
			</div>
			<div class="field">
				<input name="donor_l_name" type="text" placeholder="L Name"/>
			</div>
			<div class="field">
				<input name="donor_phone" type="text" placeholder="Phone"/>
			</div>
			<div class="field">
				<input name="donor_email" type="text" placeholder="Email"/>
			</div>
			<div class="field">
				<input name="donor_address_1" type="text" placeholder="Address 1"/>
			</div>
			<div class="field">
				<input name="donor_address_2" type="text" placeholder="Address 2"/>
			</div>
			<div class="field">
				<input name="donor_city" type="text" placeholder="City"/>
			</div>
			<div class="field">
				<input name="donor_postcode" type="text" placeholder="Postcode"/>
			</div>
			<div class="field">
				<input name="donor_donation_period" type="text" placeholder="Don. Period"/>
			</div>
			<div class="field">
				<input name="donor_giftaid" type="text" placeholder="Giftaid"/>
			</div>
			<div class="field">
				<input name="donation_amount" type="text" placeholder="Amount"/>
			</div>
			<div class="field">
				<input name="donation_name" type="text" placeholder="Don. Name"/>
			</div>
		</div>
		<table id="direct_input">
			<thead>
				<tr>
					<td>

					</td>
					<td>
						Donor F Name
					</td>
					<td>
						Donor L Name
					</td>
					<td>
						Donor Phone
					</td>
					<td>
						Donor Email
					</td>
					<td>
						Donor Address 1
					</td>
					<td>
						Donor Address 2
					</td>
					<td>
						Donor City
					</td>
					<td>
						Donor Postcode
					</td>
					<td>
						Donor Donation Period
					</td>
					<td>
						Donor Giftaid
					</td>
					<td>
						Donation Amount
					</td>
					<td>
						Donation Name
					</td>
				</tr>
			</thead>
			<tbody>
<?php
				$donation_info = array(
			    	'donation_id' => '',
			    	'donor_id' => '',
				    'donation_name' => '',
				    'donation_amount' => '',
				    'donor_f_name' => '',
				    'donor_l_name' => '',
				    'donor_phone' => '',
				    'donor_email' => '',
				    'donor_address_1' => '',
				    'donor_address_2' => '',
				    'donor_city' => '',
				    'donor_postcode' => '',
				    'donor_donation_period' => '',
				    'donor_giftaid' => ''
			    );

				if($get_donor_info = mysqli_query($con, "SELECT * FROM donors;")) {			        
			        while ($get_donor = $get_donor_info->fetch_assoc()) {
			        	$donorId = $get_donor['donor_id'];
			        	$donation_info['donor_id'] = $get_donor['donor_id'];
			        	$donation_info['donor_f_name'] = $get_donor['donor_f_name'];
					    $donation_info['donor_l_name'] = $get_donor['donor_l_name'];
					    $donation_info['donor_phone'] = $get_donor['donor_phone'];
					    $donation_info['donor_email'] = $get_donor['donor_email'];
					    $donation_info['donor_address_1'] = $get_donor['donor_address_1'];
					    $donation_info['donor_address_2'] = $get_donor['donor_address_2'];
					    $donation_info['donor_city'] = $get_donor['donor_city'];
					    $donation_info['donor_postcode'] = $get_donor['donor_postcode'];
					    $donation_info['donor_donation_period'] = $get_donor['donor_donation_period'];
					    $donation_info['donor_giftaid'] = $get_donor['donor_giftaid'];
					    if($get_donation_id = mysqli_query($con, "SELECT * FROM donor_donations WHERE donor_id = $donorId ;")) {			        
					        while ($get_donation = $get_donation_id->fetch_assoc()) {
					        	$donation_id = $get_donation['donation_id'];
					        	if($get_donation = mysqli_query($con, "SELECT * FROM donations WHERE donation_id = $donation_id;")) {			        
					        		while ($donation = $get_donation->fetch_assoc()) {
					        			$donation_info['donation_id'] = $donation['donation_id'];
					        			$donation_info['donation_amount'] = $donation['donation_amount'];
							    		$donation_info['donation_name'] = $donation['donation_name'];
					        		}
					        	}
					        }
					    }
?>
						<tr>
							<td>
								<input type="submit" value="Update" class="update_entry" name="update_entry"/>
								<input type="hidden" name="donor_id" value="<?php echo $donation_info['donor_id'];?>" />
								<input type="hidden" name="donation_id" value="<?php echo $donation_info['donation_id'];?>" />
							</td>
							<td>
								<input name="donor_f_name" value="<?php echo $donation_info['donor_f_name'];?>" type="text"/>
							</td>
							<td>
								<input name="donor_l_name" value="<?php echo $donation_info['donor_l_name'];?>" type="text"/>
							</td>
							<td>
								<input name="donor_phone" value="<?php echo $donation_info['donor_phone'];?>" type="text"/>
							</td>
							<td>
								<input name="donor_email" value="<?php echo $donation_info['donor_email'];?>" type="text"/>
							</td>
							<td>
								<input name="donor_address_1" value="<?php echo $donation_info['donor_address_1'];?>" type="text"/>
							</td>
							<td>
								<input name="donor_address_2" value="<?php echo $donation_info['donor_address_2'];?>" type="text"/>
							</td>
							<td>
								<input name="donor_city" value="<?php echo $donation_info['donor_city'];?>" type="text"/>
							</td>
							<td>
								<input name="donor_postcode" value="<?php echo $donation_info['donor_postcode'];?>" type="text"/>
							</td>
							<td>
								<input name="donor_donation_period" value="<?php echo $donation_info['donor_donation_period'];?>" type="text"/>
							</td>
							<td>
								<input name="donor_giftaid" value="<?php echo $donation_info['donor_giftaid'];?>" type="text"/>
							</td>
							<td>
								<input name="donation_amount" value="<?php echo $donation_info['donation_amount'];?>" type="text"/>
							</td>
							<td>
								<input name="donation_name" value="<?php echo $donation_info['donation_name'];?>" type="text"/>
							</td>
						</tr>
<?php
			        }
			    }
?>
			</tbody>
			<tfoot>
				<tr>
					<td>

					</td>
					<td>
						Donor F Name
					</td>
					<td>
						Donor L Name
					</td>
					<td>
						Donor Phone
					</td>
					<td>
						Donor Email
					</td>
					<td>
						Donor Address 1
					</td>
					<td>
						Donor Address 2
					</td>
					<td>
						Donor City
					</td>
					<td>
						Donor Postcode
					</td>
					<td>
						Donor Donation Period
					</td>
					<td>
						Donor Giftaid
					</td>
					<td>
						Donation Amount
					</td>
					<td>
						Donation Name
					</td>
				</tr>
			</tfoot>
		</table>	
	</div>