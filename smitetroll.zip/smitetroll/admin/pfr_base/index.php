<?php	
	include('header.php');
?>
	</header>
	<div id="content" class="visual">
		<section id ="sect1">
			<div id="logo">
				<img src="images/logo.png"/>
			</div>
			<p>PowerFundRaiser Live Donate</p>
			<div id="live_totals">
				<div class="row" data-total-type="total_raised">
					<span>Live Total:</span>
					<strong>£0</strong>
				</div>
				<div class="row" data-total-type="total_remaining">
					<span>Still Required:</span>
					<strong>£0</strong>
				</div>
			</div>
			<div id="details">
				<h3>Charity Details</h3>
				<p>
					Address:<br/>
					<b>READ Foundation</b>
				</p>
				<p>
					628 Stockport Road<br/>
					Manchester<br/>
					M13 0SH<br/>
					Tel: 0161 224 3334
				</p>
				<p>
					www.readfoundation.org.uk
					info@readfoundation.org.uk
				</p>
				<p>
					Registered Charity: 1114808
				</p>
			</div>
		</section>
		<section id ="sect2">
			<a 
				class="twitter-timeline" 
				width="250px" 
				height="630px"  
				data-dnt="true" 
				href="https://twitter.com/search?q=%23Freedom500" 
				data-widget-id="418721600762953728"
			>
				Tweets about "#Freedom500"
			</a>
			<script>
				!function(d,s,id){
					var js,fjs=d.getElementsByTagName(s)[0],p=/^http:/.test(d.location)?'http':'https';
					if(!d.getElementById(id)){
						js=d.createElement(s);
						js.id=id;
						js.src=p+"://platform.twitter.com/widgets.js";
						fjs.parentNode.insertBefore(js,fjs);
					}
				}
				(document,"script","twitter-wjs");
			</script>
		</section>
		<section id ="sect3">
			<h4>Live Donations</h4>
			<div class="overlay"></div>
			<div id="live_feed">
				<div class="donation">
					<input name="donation_id" type="hidden" value="0"/>
				</div>
			</div>
		</section>
		<section id ="sect4">
			<h4>Todays Target</h4>
			<div id="live_progress">
				<div class="target">
<?php
	if($get_event_target = mysqli_query($con, "SELECT * FROM system WHERE option_name = 'event_target';")) {
		$row = mysqli_fetch_assoc($get_event_target);		        
		$event_target = $row['option_value'];
	}
?>
					<h4>£<?php echo $event_target;?></h4>
				</div>
				<div class="progress_bar">
					<div class="overlay">
					</div>
					<div class="bar first"></div>
				</div>
			</div>
		</section>