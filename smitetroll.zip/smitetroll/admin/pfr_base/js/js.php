<?php
    include('db-details.php');
    $connection = new Connection($u, $p, $db);
    $con = $connection->connect();

    $customer = new Customer($con);
    $customerslug = $customer->get_customer_from_event($_GET['event_name']);

    include('/customers/'.$customerslug.'/db-details.php');
    $CustomerConnection = new Connection($u, $p, $db);
    $customerCon = $CustomerConnection->connect();

    $currentEvent = new Event($con, $customerslug, $_GET['event_name']);
    $currentInstallation = $currentEvent->get_installation_id($customerCon, $_GET['event_name']);
    $eventThankYou = $currentEvent->get_installation_setting($con, 'event_thank_you', $installation_id);

    if(!$eventThankYou){ 
        $thankYou = '<h1>Thank You so much!</h1><p>Thanks to your genererous contributions, we have hit out target this evening. This is not the end however; the more you give the more we can do.<p/><p>So please continue to give generously to our cause</p>';
    }
    else {
        $thankYou = $eventThankYou;
    }
    $currentPage = $_SERVER["PHP_SELF"];
    $mainDir = substr($currentPage, 0, strrpos($currentPage, '/'));

?>
<script type="text/javascript">
$ = jQuery;

function countObject(providedObject) {
    var count = 0;
    for (var k in providedObject) {
        if (providedObject.hasOwnProperty(k)) {
           ++count;
        }
    }
    return count;
}

function getRandomColor() {
    var letters = '0123456789ABCDEF'.split('');
    var color = '#';
    for (var i = 0; i < 6; i++ ) {
        color += letters[Math.floor(Math.random() * 16)];
    }
    return color;
}

function occurrences(string, subString, allowOverlapping) {
    string += "";
    subString += "";
    if (subString.length <= 0) return (string.length + 1);
    var n = 0,
        pos = 0,
        step = allowOverlapping ? 1 : subString.length;
    while (true) {
        pos = string.indexOf(subString, pos);
        if (pos >= 0) {
            ++n;
            pos += step;
        } else break;
    }
    return n;
}


// Get Donations in 1 go
function getAllDonations(){
    var event_slug = '<?php echo $_GET['event_name'];?>';
    var last_donation_id = jQuery('#live_feed .donation').first().find('input[name="donation_id"]').val();

    jQuery.ajax({
        type: "POST",
        url: '<?php echo $mainDir;?>/pfr_base/functions/get_donations.php',
        data:{lastDonation:last_donation_id, event_slug:event_slug},
        timeout: 2000,
        error: function(request,error) {
            console.log(error);
        },
        success: function(data) {
            jQuery('#live_feed').prepend(data);
            var donationQty = occurrences(data,'class="donation"');

            // Remove all donations past the last 5
            if(jQuery('#live_feed .donation').length > 5){
                while(jQuery('#live_feed .donation').length > 5){
                    jQuery('#live_feed .donation').last().remove();
                }
            }
            // Fade in all remaining donations
            jQuery('#live_feed .donation').fadeIn(1000);
        }
    });
    
    jQuery.ajax({
        type: "POST",
        url: '<?php echo $mainDir;?>/pfr_base/functions/get_donation_total.php',
        data:{event_slug:event_slug},
        timeout: 2000,
        error: function(request,error) {
            console.log(error);
        },
        success: function(data) {
            if(data){
                jQuery('#live_totals .row[data-total-type="total_raised"] strong').html('£'+data);
                var targetAmount = parseInt(jQuery('#live_progress h4').html().replace('£',''));
                var required = targetAmount - parseInt(data);
                if(required <= 0){
                    jQuery('.progress_bar').addClass('complete');
                    jQuery('#content').append(''+
                        '<div id="target_met"><?php echo $thankYou;?></div>'
                    );
                    var above = Math.abs(required);
                    jQuery('#live_totals .row[data-total-type="total_remaining"] span').html('Above target');
                    jQuery('#live_totals .row[data-total-type="total_remaining"] strong').html('£'+above);
                    jQuery('#live_progress .progress_bar .bar').css('height','100%');
                }
                else {
                    jQuery('#live_totals .row[data-total-type="total_remaining"] strong').html('£'+required);
                    var percComplete = 100 / targetAmount * data;
                    jQuery('#live_progress .progress_bar .bar').css('height',percComplete+'%');
                }
            }
            else {
                var targetAmount = jQuery('#live_progress h4').html();
                jQuery('#live_totals .row[data-total-type="total_raised"] strong').html('£0');
                jQuery('#live_totals .row[data-total-type="total_remaining"] strong').html(targetAmount);
            }
        }
    });
    
}

    // Graph
    function getAllGraphDonations(){
        var last_donation_id = jQuery('#graph .bar').last().find('input[name="donation_id"]').val();

        jQuery.ajax({
            type: "POST",
            url: '<?php echo $mainDir;?>/pfr_base/functions/get_donations_graph.php',
            data:{lastDonation:last_donation_id},
            timeout: 2000,
            error: function(request,error) {
                console.log(error);
            },
            success: function(data) {
                jQuery('#graph').append(data);
            }
        }); 

        jQuery('#timeEarliest').html(jQuery('.bar').first().children('input[name="donation_time"]').val());    
        jQuery('#timeLatest').html(jQuery('.bar').last().children('input[name="donation_time"]').val());       
    }

function submitDirect(thisobject, parent){
    var thisObj = thisobject;
    var thisRow = jQuery(thisObj).parents(parent);
    var donationData = {};
    var donorData = {};

    jQuery(thisRow).find('input').each(function(){
        if(jQuery(this).attr('name').indexOf('donation') == 0){
            if(jQuery(this).attr('name') === 'donation_name'){
                if(jQuery(this).val() === 'Anonymous'){
                    donorData['donor_anonymous'] = 'anon';
                }
            }
            var fieldName = jQuery(this).attr('name');
            donationData[fieldName] = jQuery(this).val();
        }
        else if(jQuery(this).attr('name').indexOf('donor') == 0){
            var fieldName = jQuery(this).attr('name');
            donorData[fieldName] = jQuery(this).val();
        }
    });

    donationData = JSON.stringify(donationData);
    donorData = JSON.stringify(donorData);
    
    jQuery.ajax({
        type: "POST",
        url: '<?php echo $mainDir;?>/pfr_base/functions/submit_data.php',
        data:{donationData:donationData, donorData:donorData},
        timeout: 5000,
        error: function(request,error) {
            console.log(error);
        },
        success: function(data) {
            jQuery(thisRow).fadeOut();
            jQuery(thisRow).fadeIn();
        }
    });
}

function resetLine(){
    var map = document.getElementById('linegraph');
    var ctx = map.getContext("2d");

    ctx.clearRect(0, 0, jQuery(map).width(), jQuery(map).height());

    var lineGraph = document.getElementById('linegraph');
    var ctx = lineGraph.getContext("2d");
    ctx.beginPath();
    ctx.strokeStyle = "red";
    
    var currentTotal = 0;
    var targetTotal = parseInt(jQuery('#target').html());
    var targetIncrement = 100 / targetTotal;

    var canvasHeight = jQuery('canvas#linegraph').height();
    var canvasIncrement = 100 / canvasHeight;

    ctx.moveTo(0,canvasHeight);

    jQuery('.bar').each(function(e){

        var barPerc = parseInt(jQuery(this).children('input[name="donation_amount"]').val());
        currentTotal += barPerc;

        var posX = jQuery(this).position().left + (jQuery(this).width()/2);
        var posY = canvasHeight - ((targetIncrement * currentTotal) / canvasIncrement);

        // Simply offset canvas point
        ctx.lineTo(posX,posY);
    });
    ctx.stroke();
}               

jQuery(document).ready(function(){
    var event_slug = '<?php echo $_GET['event_name'];?>';
    var installation_id = '<?php echo $currentInstallation;?>';

    jQuery('canvas#linegraph').attr('width',jQuery('canvas#linegraph').width()-5);
    jQuery('canvas#linegraph').attr('height',jQuery('canvas#linegraph').height()-5);
    jQuery('canvas#linegraph').css({
        'width' : 'auto',
        'height' : 'auto'
    });

    jQuery('.update_entry').click(function(){
        var thisObject = jQuery(this);
        jQuery(this).parents('tr').removeClass('editting');
        submitDirect(thisObject,'tr');
    });
    jQuery('#new_donor input[type="submit"]').click(function(){
        var thisObject = jQuery(this);
        submitDirect(thisObject,'#new_donor');
    });
    // Attach fixed part of form on scroll
    if(jQuery('#fixed').length){
        var offset = jQuery('#fixed').offset().top;
        jQuery(window).scroll(function(){
            if(jQuery(window).scrollTop() >= offset){
                jQuery('#fixed').addClass('sticky');
            }
            else {
                jQuery('#fixed').removeClass('sticky');
            }
        });
    }

    // If Donation Period > 12 months
    jQuery('select[name="donor_donation_period"]').change(function(){
        if(jQuery(this).val() === '12+ months'){
            if(jQuery(this).parent().parent().children('.field.don_per').length){
                jQuery(this).parent().parent().children('.field.don_per').fadeIn();
            }
            else {
                jQuery(this).parent().parent().append(''+
                    '<div class="field don_per">'+
                        '<input type="text" name="donor_donation_period" placeholder="Donation period"/>'+
                    '</div>'
                );
            }
        }
        else {
            jQuery(this).parent().parent().children('.field.don_per').fadeOut();
            jQuery(this).parent().parent().children('.field.don_per').children('input').val('')
        }
    });

    // If choose existing donor
    jQuery('select[name="choose_donor"]').change(function(){
        if(jQuery(this).val()){
            var donorId = jQuery(this).val();
            jQuery.ajax({
                type: "POST",
                url: '<?php echo $mainDir;?>/pfr_base/functions/get_single_donor.php',
                data:{donorId:donorId, event_slug:event_slug},
                timeout: 2500,
                error: function(request,error) {
                    console.log(error);
                },
                success: function(data) {
                    console.log(data);
                    var donation = JSON.parse(data);
                    var donation_array = Object.keys(donation);

                    // Foreach input, add value
                    for(i = 0; i < countObject(donation); i++){
                        var donation_property = donation_array[i];
                        jQuery('input[name="'+donation_property+'"]:not([type="checkbox"]').val(donation[donation_property]);
                    }

                    // For non-box inputs
                    if(donation.donation_name === 'anon'){
                        jQuery('input[name="donor_anonymous"]').prop('checked',true);
                    }
                    else if(donation.donation_name !== 'anon'){
                        jQuery('input[name="donor_anonymous"]').prop('checked',false);
                    }
                    if(donation.donor_giftaid){
                        jQuery('input[name="donor_giftaid"]').prop('checked',true);
                    }
                    else{
                        jQuery('input[name="donor_giftaid"]').prop('checked',false);
                    }

                    if(parseInt(donation.donor_donation_period) > 12) {
                        jQuery('option[value="12+ months"]').prop('selected',true);
                        jQuery('select[nane="donor_donation_period"]').parent().append(''+
                            '<div class="field don_per">'+
                                '<input type="text" name="donor_donation_period" placeholder="Donation period">'+
                            '</div>'
                        );
                        jQuery('input[name="donor_donation_period"]').val(donation.donor_donation_period);
                    }
                    else {
                        jQuery('option[value="'+donation.donor_donation_period+'"]').prop('selected',true);
                    }

                    // Add chosen doner and donation ids to forms
                    jQuery('form').each(function(){
                        jQuery(this).children('.form_sub_ids').remove();
                        jQuery(this).append(''+
                            '<div class="form_sub_ids">'+
                                '<input type="hidden" name="donation_id" value="'+donation.donation_id+'">'+
                                '<input type="hidden" name="donor_id" value="'+donation.donor_id+'">'+
                           '</div>'
                        );
                    });
                    
                }
            });
        }
    });
    
    // Submit form for donation
    jQuery('form:not(.normal_sub)').submit(function(e){
        e.preventDefault();
        var thisForm = jQuery(this);
        var functionURL = jQuery(this).attr('action');
        var donationData = {};
        var donorData = {};
        jQuery('form').find('input').each(function(){
            if(jQuery(this).attr('name').indexOf('donation') == 0){
                var fieldName = jQuery(this).attr('name');
                donationData[fieldName] = jQuery(this).val();
            }
            else if(jQuery(this).attr('name').indexOf('donor') == 0){
                if(jQuery(this).attr('type') === 'checkbox'){
                    if(jQuery(this).is(':checked')){
                        var fieldName = jQuery(this).attr('name');
                        donorData[fieldName] = jQuery(this).val();
                    }
                }
                else {
                    var fieldName = jQuery(this).attr('name');
                    donorData[fieldName] = jQuery(this).val();
                }
            }
        });

        jQuery('form').find('select').each(function(){
            if(jQuery(this).attr('name').indexOf('donation') == 0){
                var fieldName = jQuery(this).attr('name');
                donationData[fieldName] = jQuery(this).val();
            }
            else if(jQuery(this).attr('name').indexOf('donor') == 0){
                var fieldName = jQuery(this).attr('name');
                donorData[fieldName] = jQuery(this).val();
            }
        });
        if(jQuery('select[name="donor_donation_period"]').val() === '12+ months'){
            donorData['donor_donation_period'] = jQuery('input[name="donor_donation_period"]').val();
        }
        else {
            donorData['donor_donation_period'] = jQuery('select[name="donor_donation_period"]').val();
        }

        donationData = JSON.stringify(donationData);
        donorData = JSON.stringify(donorData);
        
        jQuery.ajax({
            type: "POST",
            url: '<?php echo $mainDir;?>/'+functionURL,
            data:{donationData:donationData, donorData:donorData, event_slug:event_slug, installation_id:installation_id},
            timeout: 5000,
            error: function(request,error) {
                console.log(error);
            },
            success: function(data) {
                jQuery('form').find('.form_sub_ids').html(data);
                jQuery('#form_2').slideDown();
            }
        });

    });
    
    if(jQuery('div#content.main_view').length){
        setInterval(function(){
            jQuery('table tbody tr').removeClass('checked');
            setInterval(function(){
                var checkRow = jQuery('table tbody tr:not(.checked,.editting)').first();
                if(jQuery(checkRow).length){
                    var checkDonor = jQuery(checkRow).find('input[name="donor_id"]').val();
                    var checkDonation = jQuery(checkRow).find('input[name="donation_id"]').val();

                    jQuery.ajax({
                        type: "POST",
                        url: '<?php echo $mainDir;?>/pfr_base/functions/get_single_donation_direct.php',
                        data:{lastDonation:checkDonation, lastDonor:checkDonor },
                        timeout: 2000,
                        error: function(request,error) {
                            console.log(error);
                        },
                        success: function(data) {
                            var donation = JSON.parse(data);
                            var donation_array = Object.keys(donation);

                            // Foreach input, add value
                            for(i = 0; i < countObject(donation); i++){
                                var donation_property = donation_array[i];
                                if(jQuery(checkRow).find('input[name="'+donation_property+'"]').val() != donation[donation_property]){
                                    jQuery(checkRow).find('input[name="'+donation_property+'"]').val(donation[donation_property]);
                                    jQuery(checkRow).find('input[name="'+donation_property+'"]').fadeOut();
                                    jQuery(checkRow).find('input[name="'+donation_property+'"]').fadeIn();
                                }
                            }
                            jQuery(checkRow).addClass('checked');
                        }
                    });
                }
            }, 1000);
        }, 15000);
        setInterval(function(){
            var checkRow = jQuery('table tbody tr').last();
            var checkDonor = jQuery(checkRow).find('input[name="donor_id"]').val();
            var checkDonation = jQuery(checkRow).find('input[name="donation_id"]').val();
            
            jQuery.ajax({
                type: "POST",
                url: '<?php echo $mainDir;?>/pfr_base/functions/get_new_donation_direct.php',
                data:{lastDonation:checkDonation, lastDonor:checkDonor},
                timeout: 2000,
                error: function(request,error) {
                    console.log(error);
                },
                success: function(data) {
                    if(data){
                        var donation = JSON.parse(data);
                        var donation_array = Object.keys(donation);

                        if(donation.donation_id != checkDonation && donation.donation_id){
                            jQuery('table#direct_input tbody').append('<tr></tr>');
                            var newRow = jQuery('table#direct_input tbody tr').last();
                            jQuery(newRow).append(''+
                                '<td>'+
                                    '<input type="submit" value="Update" class="update_entry" name="update_entry">'+
                                    '<input type="hidden" name="donor_id" value="'+donation.donor_id+'">'+
                                    '<input type="hidden" name="donation_id" value="'+donation.donation_id+'">'+
                                '</td>'
                            );
                            // Foreach input, add value
                            for(i = 2; i < countObject(donation); i++){
                                var donation_property = donation_array[i];
                                jQuery(newRow).append(''+
                                    '<td>'+
                                        '<input name="'+donation_property+'" value="'+donation[donation_property]+'" type="text">'+
                                    '</td>'
                                );
                            }
                        }
                    }
                }
            });
        }, 2500);
    }

    jQuery('table#direct_input input:not(.update_entry)').on('input',function(){
        jQuery(this).parents('tr').addClass('editting');
    });

    if(jQuery('#content.visual').length){
        // Get all Donations
            getAllDonations();

        // Get Donations 1 by 1
            setInterval(function(){
                jQuery('.progress_bar').each(function(){
                    var height = jQuery(this).height();
                    var width = jQuery(this).width();

                    var capacity = height * width;

                    var pixelCapacity = parseInt(jQuery('#live_progress h4').html().replace('£','')) / capacity;
                });

                var last_donation_id = jQuery('#live_feed .donation').first().find('input[name="donation_id"]').val();

                jQuery.ajax({
                    type: "POST",
                    url: '<?php echo $mainDir;?>/pfr_base/functions/get_single_donation.php',
                    data:{lastDonation:last_donation_id, event_slug:event_slug},
                    timeout: 2000,
                    error: function(request,error) {
                        console.log(error);
                    },
                    success: function(data) {
                        jQuery('#live_feed').prepend(data);
                        if(jQuery('#live_feed .donation').length > 5){
                            jQuery('#live_feed .donation').last().remove();
                        }
                        jQuery('#live_feed .donation').first().fadeIn(1000);
                        
                    }
                });
            
                jQuery.ajax({
                    type: "POST",
                    url: '<?php echo $mainDir;?>/pfr_base/functions/get_donation_total.php',
                    data:{event_slug:event_slug},
                    timeout: 2000,
                    error: function(request,error) {
                        console.log(error);
                    },
                    success: function(data) {
                        console.log(data);
                        if(data){
                            jQuery('#live_totals .row[data-total-type="total_raised"] strong').html('£'+data);
                            var targetAmount = parseInt(jQuery('#live_progress h4').html().replace('£',''));
                            var required = targetAmount - parseInt(data);
                            if(required <= 0){
                                jQuery('.progress_bar').addClass('complete');
                                if(!jQuery('#target_met').length) {
                                    jQuery('#content').append(''+
                                        '<div id="target_met">'+
                                            '<h1>Thank You so much!</h1>'+
                                            '<p>Thanks to your genererous contributions, we have hit out target this evening. This is not the end however; the more you give the more we can do.<p/>'+
                                            '<p>So please continue to give generously to our cause</p>'+
                                        '</div>'
                                    );
                                    jQuery('#target_met').fadeIn(2000);
                                    setTimeout(function(){
                                        jQuery('#target_met').fadeOut(5000);
                                    }, 120000);
                                }
                                var above = Math.abs(required);
                                var percComplete = 100 / targetAmount * above;

                                var hs = 0;
                                do{
                                    hs++;
                                    if(jQuery('#live_progress .progress_bar .bar').length - 1 < hs){
                                        jQuery('#live_progress .progress_bar').append('<div class="bar"></div>');
                                        jQuery('#live_progress .progress_bar .bar').last().css('height','0%');
                                    }
                                    if((hs*100) < percComplete){
                                        jQuery('#live_progress .progress_bar .bar').last().css('height','0%');
                                        jQuery('#live_progress .progress_bar .bar').last().css('height','100%');
                                    }
                                    else {
                                        if(percComplete < 100){
                                            jQuery('#live_progress .progress_bar .bar').last().css('height','0%');
                                            jQuery('#live_progress .progress_bar .bar').last().css('height', percComplete+'%');
                                        }
                                        else {
                                            jQuery('#live_progress .progress_bar .bar').last().css('height','0%');
                                            jQuery('#live_progress .progress_bar .bar').last().css('height', 100 +(percComplete - (hs*100))+'%');
                                        }
                                    }
                                }
                                while((hs*100) < Math.ceil(percComplete));

                                jQuery('.progress_bar .overlay').css({
                                    'background' :'url("./images/marker'+(hs+1)+'.png")',
                                    'background-repeat' : 'no-repeat',
                                    'background-size' : '100%',
                                    'background-position' : 'center'
                                });

                                jQuery('#live_totals .row[data-total-type="total_remaining"] span').html('Above target');
                                jQuery('#live_totals .row[data-total-type="total_remaining"] strong').html('£'+above);
                                jQuery('#live_progress .progress_bar .bar').first().css('height','100%');
                            }
                            else {
                                jQuery('#live_totals .row[data-total-type="total_remaining"] strong').html('£'+required);
                                var percComplete = 100 / targetAmount * data;
                                jQuery('#live_progress .progress_bar .bar').css('height',percComplete+'%');
                            }
                        }
                        else {
                            var targetAmount = jQuery('#live_progress h4').html();
                            jQuery('#live_totals .row[data-total-type="total_raised"] strong').html('£0');
                            jQuery('#live_totals .row[data-total-type="total_remaining"] strong').html(targetAmount);
                        }
                    }
                });
            }, 1000);
    }

    // Graph donations
    if(jQuery('#graph').length){
        // Get all Donations
            getAllGraphDonations();
            var totalTarget = jQuery('')
        // Get Donations 1 by 1

            setInterval(function(){
                var last_donation_id = jQuery('#graph .bar').last().find('input[name="donation_id"]').val();
                


                if(last_donation_id) {
                    jQuery.ajax({
                        type: "POST",
                        url: '<?php echo $mainDir;?>/pfr_base/functions/get_single_donation_graph.php',
                        data:{lastDonation:last_donation_id},
                        timeout: 2000,
                        error: function(request,error) {
                            console.log(error);
                        },
                        success: function(data) {
                            jQuery('#graph').append(data);
                            jQuery('#timeLatest').html(jQuery('.bar').last().children('input[name="donation_time"]').val());
                        }
                    });
                }

                // Apply heights
                var maxAmount = parseInt(jQuery('#highestAmount').html());
                var barCount = jQuery('.bar').length;
                var barWidth = 100 / barCount;
                jQuery('#graph .bar').each(function(index){
                    var amount = parseInt(jQuery(this).children('input[name="donation_amount"]').val());

                    if(amount > maxAmount) {
                        jQuery('#highestAmount').html(amount);

                        maxAmount = amount;
                    }

                    var barHeight = (100 / maxAmount) * amount;
                    if(barCount < 4) {
                        var barOffset = index * 25;
                    }
                    else {
                        var barOffset = index * barWidth;
                    }
                    jQuery(this).css({
                        'height' : barHeight+'%',
                        'width' : barWidth+'%',
                        'left' : barOffset+'%'
                    });
                });
                resetLine();
            }, 1000);

            setInterval(function(){
                jQuery('.bar').each(function(){
                    var checkRow = jQuery(this);
                    var checkDonation = jQuery(checkRow).find('input[name="donation_id"]').val();

                    jQuery.ajax({
                        type: "POST",
                        url: '<?php echo $mainDir;?>/pfr_base/functions/get_single_donation_direct.php',
                        data:{lastDonation:checkDonation},
                        timeout: 2000,
                        error: function(request,error) {
                            console.log(error);
                        },
                        success: function(data) {
                            var donation = JSON.parse(data);
                            var donation_array = Object.keys(donation);

                            // Foreach input, add value
                            for(i = 0; i < countObject(donation); i++){
                                var donation_property = donation_array[i];
                                if(jQuery(checkRow).find('input[name="'+donation_property+'"]').val() != donation[donation_property]){
                                    jQuery(checkRow).find('input[name="'+donation_property+'"]').val(donation[donation_property]);
                                }
                            }
                        }
                    });
                    
                });
            }, 15000);
    }

});
</script>