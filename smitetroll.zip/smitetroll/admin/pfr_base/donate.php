<?php	
		include('header.php');
?>
		<h5>Powered by www.powerfundraiser.co.uk</h5>
		<div id="form_logo">
			<img src="images/form_logo.jpg"/>
		</div>
	</header>
	<div id="content" class="form-container">
		<div id="form_1">
			<form id="donation_details" action="functions/submit_data.php" method="post">
				<h2>Donation Details</h2>

				<div class="field_row">
					<div class="field">
						<input type="number" placeholder="Amount" name="donation_amount" min="1"/>
					</div>
				</div>

				<div class="field_row">
					<div class="field col2">
						<input type="text" placeholder="First Name" name="donor_f_name"/>
					</div>
					<div class="field col2">
						<input type="text" placeholder="Last Name" name="donor_l_name"/>
					</div>
				</div>
				<div class="field_row">
					<div class="field">
						<label class="checkboxLabel" for="donor_anonymous">Anonymous?</label>
						<input id="donor_anonymous" type="checkbox" name="donor_anonymous" value="yes"/>
					</div>
				</div>

				<div class="field_row">
					<div class="field col2">
						<input type="text" placeholder="Phone Number" name="donor_phone"/>
					</div>
					<div class="field col2">
						<input type="text" placeholder="Email Address" name="donor_email"/>
					</div>
				</div>

				<input type="submit" name="submit"/>
				<div class="form_sub_ids"></div>
			</form>
		</div>
		<div id="form_2">
			<form id="donor_details" action="functions/submit_data.php" method="post">
				<h2>Donor Details</h2>

				<div class="field_row">
					<div class="field col2">
						<input type="text" placeholder="Address Line 1" name="donor_address_1"/>
					</div>
					<div class="field col2">
						<input type="text" placeholder="Address Line 2" name="donor_address_2"/>
					</div>
				</div>

				<div class="field_row">
					<div class="field col2">
						<input type="text" placeholder="City" name="donor_city"/>
					</div>
					<div class="field col2">
						<input type="text" placeholder="Postcode" name="donor_postcode"/>
					</div>
				</div>

				<div class="field_row">
					<div class="field">
						<select name="donor_donation_period">
							<option>Donation Period</option>
							<option value="single">Single</option>
							<option value="1 month">1 Month</option>
							<option value="2 months">2 Months</option>
							<option value="3 months">3 Months</option>
							<option value="4 months">4 Months</option>
							<option value="5 months">5 Months</option>
							<option value="6 months">6 Months</option>
							<option value="7 months">7 Months</option>
							<option value="8 months">8 Months</option>
							<option value="9 months">9 Months</option>
							<option value="10 months">10 Months</option>
							<option value="11 months">11 Months</option>
							<option value="12 months">12 Months</option>
							<option value="12+ months">12+ Months</option>
						</select>
					</div>
				</div>
				<div class="field_row">
					<div class="field">
						<label class="checkboxLabel" for="donor_giftaid">Gift Aid?</label>
						<input id="donor_giftaid" type="checkbox" name="donor_giftaid" value="yes"/>
					</div>
				</div>

				<input type="submit" name="submit"/>
				<div class="form_sub_ids"></div>
			</form>
		</div>

	</div>