<?php
	include('db-details.php');
	$connection = new Connection($u, $p, $db);
    $mainCon = $connection->connect();

    $customer = new Customer($mainCon);
    $customerslug = $customer->get_customer_from_event($_GET['event_name']);

    include('customers/'.$customerslug.'/db-details.php');
    $CustomerConnection = new Connection($u, $p, $db);
    $con = $CustomerConnection->connect();

    $currentEvent = new Event($mainCon, $customerslug, $_GET['event_name']);
    $installation_id = $currentEvent->get_installation_id($con, $_GET['event_name']);

	$bgColour = $currentEvent->get_installation_customisation($con, 'bg_colour', $installation_id);
	$buttonBGColour = $currentEvent->get_installation_customisation($con, 'button_bg_colour', $installation_id);
	$buttonColour = $currentEvent->get_installation_customisation($con, 'button_text_colour', $installation_id);
	$valueColour = $currentEvent->get_installation_customisation($con, 'value_colour', $installation_id);
	$valueBoxColour = $currentEvent->get_installation_customisation($con, 'value_box_colour', $installation_id);
	$sect1Colour = $currentEvent->get_installation_customisation($con, 'sect_1_bg_colour', $installation_id);
	$sect2Colour = $currentEvent->get_installation_customisation($con, 'sect_2_bg_colour', $installation_id);
	$sect3Colour = $currentEvent->get_installation_customisation($con, 'sect_3_bg_colour', $installation_id);
	$sect4Colour = $currentEvent->get_installation_customisation($con, 'sect_4_bg_colour', $installation_id);
	$barColour = $currentEvent->get_installation_customisation($con, 'bar_colour', $installation_id);
	$addBarColour = $currentEvent->get_installation_customisation($con, 'add_bar_colour', $installation_id);
	$addBarOpacity = $currentEvent->get_installation_customisation($con, 'add_bar_opacity', $installation_id);

	if(!$bgColour) $bgColour = '#4DB747';
	if(!$buttonBGColour) $buttonBGColour = '#3f9c0d';
	if(!$buttonColour) $buttonColour = '#ffffff';
	if(!$valueColour) $valueColour = '#3f9c0d';
	if(!$valueBoxColour) $valueBoxColour = '#eeeeee';
	if(!$sect1Colour) $sect1Colour = '#ffffff';
	if(!$sect2Colour) $sect2Colour = '#ffffff';
	if(!$sect3Colour) $sect3Colour = 'linear-gradient(to right, #bbbbbb, #eeeeee, #eeeeee, #eeeeee, #eeeeee, #bbbbbb)';
	if(!$sect4Colour) $sect4Colour = '#ffffff';
	if(!$barColour) $barColour = '#4DB747';
	if(!$addBarColour) $addBarColour = '#3B6038';
	if(!$addBarOpacity) $addBarOpacity = '0.25';
?>
<style>
@import url(http://fonts.googleapis.com/css?family=Open+Sans:300,400);

@font-face {
  font-family: 'Fjalla One';
  font-style: normal;
  font-weight: 400;
  src: local('Fjalla One'), local('FjallaOne-Regular'), url(http://themes.googleusercontent.com/static/fonts/fjallaone/v2/rxxXUYj4oZ6Q5oDJFtEd6hsxEYwM7FgeyaSgU71cLG0.woff) format('woff');
}
/* General */
	
	.overlay {
		position: absolute;
		top: 0;
		left: 0;
		width: 100%;
		height: 100%;
		z-index: 999;
	}

	body {
		margin: 0;
		background: url(../pfr_base/images/bg.png) repeat;
	}

		header {
			text-align: center;
		}

		div#content {
		    display: block;
		    max-width: 1000px;
		    height: 650px;
		    margin: 10px auto 0;
    	    box-shadow: 0px 0px 10px #000000;
	        position: relative;
		}

			#content > section {
			    float: left;
			    width: 27%;
			    height: 100%;
			    padding: 10px;
			    box-sizing: border-box;
			    overflow: hidden;
			    position: relative;
			}
			section#sect1 {
				padding: 20px 10px 20px 20px;
			}
			section#sect2 {
				
			}
			section#sect3 {

			}
			section#sect4 {
			    width: 19%;
			}
				#content > section > h4{
				    margin: 0;
				    text-align: center;
				    border-radius: 5px;
					padding: 10px;
					font-size: 17px;
					font-family: 'Fjalla One', sans-serif;
				}

				#sect3 .overlay {
					position: absolute;
					top: 0;
					left: 0;
					width: 100%;
					height: 100%;
					background: linear-gradient(transparent, rgba(255,255,255,0.75));
				}

			/* Details Section */
				div#logo {
					max-height: 135px;
					margin-bottom: 10px;
				}

					div#logo img {
						height: 135px;
						width: auto;
						max-width: 100%;
						display: block;
						margin: auto;
					}

				#sect1 > p {
				    font-size: 18px;
				    font-family: 'Fjalla One', sans-serif;
				    margin: 0;
				    color: #999999;
				    text-transform: uppercase;
				}
				div#live_totals {
				    padding: 10px;
				    background: #eeeeee;
				}

					div#live_totals .row {
						display: block;
						margin-bottom: 20px;
					}
					div#live_totals .row:last-of-type {
						margin-bottom: 0;
					}

						div#live_totals .row span {
							display: block;
							font-family: 'Open Sans', sans-serif;
							font-size: 12px;
							text-transform: uppercase;
							font-weight: bold;
						}

						div#live_totals .row strong {
							display: block;
							font-family: 'Fjalla One', sans-serif;
							font-size: 38px;
						}

				div#details {

				}

					div#details h3 {
						font-family: 'Fjalla One', sans-serif;
						font-size: 24px;
						text-transform: uppercase;
						font-weight: normal;
					}

					div#details p {
						font-size: 12px;
						font-family: 'Open Sans', sans-serif;
					}

			/* Donation Feed */
				#live_feed {

				}

					#live_feed .donation {
					    display: none;
					    padding: 15px 0;
					    border-top: 1px solid #000000;
					}
					#live_feed .donation:first-of-type {
						border: 0;
					}

						#live_feed .donation h4 {
						    margin: 0 0 5px;
						    font-size: 26px;
						    text-transform: uppercase;
						    font-family: 'Fjalla One', sans-serif;
						}

						#live_feed .donation h3 {
							margin: 0;
						    font-size: 18px;
						    border-radius: 5px;
						    padding: 5px 10px;
						    text-align: left;
						    display: inline-block;
						    font-size: 22px;
						    font-family: 'Fjalla One', sans-serif;
						}

						#live_feed .donation span {
						    text-align: left;
						    float: right;
						    margin-top: 7px;
						}

			/* Progress Bar */
				#live_progress {
					width: 100%;
					height: calc(100% - 45px);;
				}	

					#live_progress .target {

					}
						#live_progress .target h4 {
							text-align: center;
						    margin: 5px 0 0;
						    border-radius: 5px;
						    padding: 10px;
						    font-size: 26px;
						    font-family: 'Fjalla One', sans-serif;
						}

					#live_progress .progress_bar {
						position: relative;
					    height: calc(100% - 60px);
					    width: 100%;
					    margin-top: 10px;
					    border: 1px solid #000000;
					    box-sizing: border-box;
			         	overflow: hidden;
    					border-radius: 15px 15px 90px 90px;
					}
					.progress_bar.complete {
					    box-shadow: 0 0 30px green;
					}

						#live_progress .progress_bar .bar {
							position: absolute;
							bottom: 0;
							left: 0;
							width: 100%;
							transition: all linear 1s;
							height: 0;
						}

						.progress_bar .overlay {
						    background: linear-gradient(to top, transparent, rgba(255,255,255,0.75));
						    background: url('../pfr_base/images/marker1.png');
						    background-repeat: no-repeat;
						    background-size: 100%;
						    background-position: center;
						}

		/* Target Met */

			div#target_met {
		        display: none;
			    position: absolute;
			    bottom: 0;
			    left: 0;
			    width: 54%;
			    height: 50%;
			    background: rgba(255,255,255,1);
			    text-align: center;
			    padding: 20px;
			    box-sizing: border-box;
			    border: 1px solid #000000;
			    z-index: 999;
			    box-shadow: 5px 5px 20px #000000;
			}

				#target_met h1 {
				    font-size: 3em;
				    font-family: 'Fjalla One', sans-serif;
				}

				div#target_met p {
				    font-size: 1em;
				    font-family: 'Open Sans', sans-serif;
				}

/* Form */
	
	div#content.form-container {
		padding: 20px;
		height: auto;
		margin-bottom: 50px;
	}

		div#content.form-container > div {
			margin-bottom:20px;
		}
		div#form_1 {
			margin-top: 102px;
		}

		div#content.form-container div#fixed {
		    position: absolute;
		    width: 1000px;
		    overflow: hidden;
		    padding: 20px;
		    background: #ffffff;
		    margin: 0 -20px 10px;
		    border-bottom: 1px solid #cccccc;
		}
		div#content.form-container div#fixed.sticky {
			position: fixed;
			top: 20px;
			margin: -20px;
			box-shadow: 0 3px 5px #000000;
		}
			div#fixed a {
			    float: right;
			    text-decoration: none;
			    border-radius: 5px;
			    border: 1px solid #ccc;
			    text-align: center;
			    font-size: 2em;
			    padding: 11px;
			    font-family: Arial;
			}

			div#fixed select {
				width: 80%;
				float: left;
			}

			div#content.form-container h2 {
				margin: 0 0 10px;
				font-size: 3em;
				font-family: 'Fjalla One', sans-serif;
			}

			.field_row {
				margin-bottom: 10px;
				overflow: hidden;
			}

				.field {
					width: 100%;
				}
				.field.col2 {
					width: calc(50% - 10px);
					display: inline-block;
					margin-right: 10px;
					float: left;
				}
				.field.col2:nth-of-type(2) {
					margin-right: 0;
					margin-left: 10px;
				}

			input, select, textarea {
				width: 100%;
				padding: 10px;
				border-radius: 5px;
				box-sizing: border-box;
				border: 1px solid #cccccc;
				font-size: 2em;
			}
			textarea {
				font-size: 1em;
				min-height: 75px;
			}

			input[type="checkbox"] {
			    height: 30px;
			    width: 30px;
			    border: 1px solid #cccccc;
			    border-radius: 5px;
			    float: left;
			}

			label.checkboxLabel{
				font-size: 2em;
			    margin-top: 0;
			    margin-left: 15px;
			    display: inline-block;
			    font-family: 'Fjalla One', sans-serif;
			}

			.field.don_per {
			    margin-top: 10px;
			}

			.donationInfo {
			    position: absolute;
			    left: 0;
			    width: 200px;
			    border: 1px solid #cccccc;
			    background: #ffffff;
			    z-index: 999;
			    box-sizing: border-box;
			    display: none;
			}

/* Direct Input */
	
	div#content.main_view {
		padding: 10px;
		height: auto;
		min-height: 100%;
		max-height: none;
		margin-top: 0;
	    max-width: 1200px;
	}
		div#new_donor {
		    position: fixed;
		    background:  #ffffff;
		    box-sizing: border-box;
		    z-index: 1;
	       	margin-left: -10px;
		    box-shadow: 0 3px 5px #000000;
		    width: 1220px;
		    padding: 10px;
	        margin-top: -10px;
	        border-bottom: 1px solid #cccccc;
		}
		div#new_donor h2 {
			text-align: center;
			margin: 0 0 10px;
			font-family:'Fjalla', sans-serif;
		}
			div#new_donor .field {
			    float:  left;
			    width: calc(((100% - 48px) / 13));
			    z-index: 10;
			    margin-left: 4px;
			}
			div#new_donor .field:first-of-type {
			    margin-left: 0;
			}

				div#new_donor .field input {
					font-size: 0.75em;
				}

		table#direct_input {
			margin-top: 100px;
		}

			table#direct_input tr {

			}
			table#direct_input tr.editting {
			    background-color: rgba(255, 255, 0, 0.5);
			}
				table#direct_input td {
					position: relative;
					font-family:'Open Sans', sans-serif;
				}

					table#direct_input td input {
						font-size: 1em;
						background: transparent;
					}
					table#direct_input td input:not([type="submit"]):focus {
						width: 200px;
						position: absolute;
						top: 0;
						left: 0;
						z-index: 1;
						background: #ffffff;
					}

/* Graph */

	#graphContainer {
		width: 90%;
	    height: 90%;
	    display: block;
	    position: absolute;
	    top: 5%;
	    left: 5%;
	}
		#graphContainer .label {
		    position: absolute;
		    top: 0;
		    left: 0;
		    background: transparent;
		    color: #ffffff;
		    z-index: 5;
		}
		#graphContainer #target.label {
			left: auto;
    		right: -60px;
		}
			#graphContainer #target.label:before {
			    content: '£';
			}
		#graphContainer #highestAmount.label {
			left: -65px;
		}
			#graphContainer #highestAmount.label:before {
			    content: '£';
			}
		#graphContainer #lowestAmount.label {
			top: auto;
			bottom: 0;
			left: -20px;
		}
			#graphContainer #lowestAmount.label:before {
			    content: '£';
			}
		#graphContainer #timeEarliest.label {
			top: auto;
			bottom: -20px;
		}
		#graphContainer #timeLatest.label {
			top: auto;
			right: 0;
			bottom: -20px;
			left: auto;
		}

		#graphContainer label {
			position: absolute;
			display: block;
			margin: auto;
			width: auto;
			height: 20px;
		}
		label#targetComplete {
		    top: 0;
		    bottom: 0;
		    right: -50px;
		    transform: rotate(90deg);
		}
		label#amountDonated {
		    top: 0;
		    bottom: 0;
		    left: -80px;
		    transform: rotate(-90deg);
		}
		label#timeDonations {
		    right: 0;
		    bottom: -30px;
		    left: 0;
		    text-align: center;
		}



		div#graph {
		    position: absolute;
		    width: 100%;
		    height: 100%;
		    background: #ffffff;
		    top: 0;
		    left: 0;
		    border: 5px solid green;
		    border-right: 0;
		    border-top: 0;
		    box-sizing: border-box;
		}

			#graph .bar {
				position: absolute;
				max-width: 25%;
				height: 0;
				background: #3f9c0d;
				bottom: 0;
				transition: all linear 1s;
				border: 1px solid #61DD1E;
				border-left: 0;
				border-bottom: 0;
				box-sizing: border-box;
			}

		canvas#linegraph {
			width: 100%;
			height: 100%;
			position: absolute;
			top: 0;
			right: 0;
			z-index: 1;
		}


/* Responsive */

	@media screen and (max-width: 1000px){
		div#content.form-container div#fixed {
		    width: 100%;
		}
		div#content.form-container div#fixed.sticky {
		    box-sizing: border-box;
		}
    
			div#fixed a {
				width: 100%;
			    float: left;
			    box-sizing: border-box;
			    border-bottom: 0;
			}

			div#fixed select {
				width: 100%;
				float: left;
			}
	}

	@media screen and (max-width: 550px){
		.field.col2 {
			width: 100%;
			margin: 0 0 10px;
		}
		.field.col2:nth-of-type(2) {
			margin: 0;
		}
	}

/* Theming */
	
	/* General */

		body {
			margin: 0;
			background-color: <?php echo $bgColour;?>;
		}

			div#content {
				
			}

				section#sect1 {
					background: <?php echo $sect1Colour;?>;
				}
				section#sect2 {
					background: <?php echo $sect2Colour;?>;
				}
				section#sect3 {
					background: <?php echo $sect3Colour;?>;
				}
				section#sect4 {
					background: <?php echo $sect4Colour;?>;
				}

					#content > section > h4 {
					    color: <?php echo $buttonColour;?>;
					    background: <?php echo $buttonBGColour;?>;
					}

				/* Details Section */

					div#live_totals .row strong {
						color: <?php echo $valueColour;?>;
					}

				/* Donation Feed */

					#live_feed .donation h3 {
						color: <?php echo $buttonColour;?>;
					    background: <?php echo $buttonBGColour;?>;
					}

				/* Progress bar */
					#live_progress .target h4 {
						color: <?php echo $buttonColour;?>;
					    background: <?php echo $buttonBGColour;?>;
					}
					.progress_bar.complete {
					    box-shadow: 0 0 30px green;
					}
					#live_progress .progress_bar .bar.first {
						background: <?php echo $barColour;?>;
					}
					#live_progress .progress_bar .bar {
						background: <?php echo $addBarColour;?>;
						opacity: <?php echo $addBarOpacity;?>;
					}

		/* Target Met */

			#target_met h1 {
				color: #4DB747;
			}


		/* Form */

			div#fixed a {
				color: #ffffff;
				background: #4DB747;
			}

</style>