<?php	
	include('../db-details.php');
	$mysqli= new mysqli("localhost","$u","$p","$db");
    $con=mysqli_connect("localhost","$u","$p","$db");

    $donation_id = $_POST['lastDonation'];
    $donorId = $_POST['lastDonor'];

    $donation_info = array(
    	'donation_id' => '',
    	'donor_id' => '',
	    'donor_f_name' => '',
	    'donor_l_name' => '',
	    'donor_phone' => '',
	    'donor_email' => '',
	    'donor_address_1' => '',
	    'donor_address_2' => '',
	    'donor_city' => '',
	    'donor_postcode' => '',
	    'donor_donation_period' => '',
	    'donor_giftaid' => '',
	    'donation_amount' => '',
	    'donation_name' => ''
    );

    if($get_donor_info = mysqli_query($con, "SELECT * FROM donors WHERE donor_id > $donorId ORDER BY donor_id ASC LIMIT 1;")) {			        
        while ($get_donor = $get_donor_info->fetch_assoc()) {
        	$donation_info['donor_id'] = $get_donor['donor_id'];
        	$donation_info['donor_f_name'] = $get_donor['donor_f_name'];
		    $donation_info['donor_l_name'] = $get_donor['donor_l_name'];
		    $donation_info['donor_phone'] = $get_donor['donor_phone'];
		    $donation_info['donor_email'] = $get_donor['donor_email'];
		    $donation_info['donor_address_1'] = $get_donor['donor_address_1'];
		    $donation_info['donor_address_2'] = $get_donor['donor_address_2'];
		    $donation_info['donor_city'] = $get_donor['donor_city'];
		    $donation_info['donor_postcode'] = $get_donor['donor_postcode'];
		    $donation_info['donor_donation_period'] = $get_donor['donor_donation_period'];
		    $donation_info['donor_giftaid'] = $get_donor['donor_giftaid'];
        }
    }
    if($get_donor_onation = mysqli_query($con, "SELECT * FROM donor_donations WHERE donor_id = ".$donation_info['donor_id'].";")) {			        
		while ($donor_donation = $get_donor_onation->fetch_assoc()) {
			$donation_info['donation_id'] = $donor_donation['donation_id'];
			if($get_donation = mysqli_query($con, "SELECT * FROM donations WHERE donation_id = ".$donation_info['donation_id'].";")) {			        
				while ($donation = $get_donation->fetch_assoc()) {
					$donation_info['donation_amount'] = $donation['donation_amount'];
		    		$donation_info['donation_name'] = $donation['donation_name'];
				}
			}
		}
	}
	
           
    $json = json_encode($donation_info);

    echo $json;
?>