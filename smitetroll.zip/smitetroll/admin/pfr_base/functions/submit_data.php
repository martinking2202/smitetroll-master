<?php	
	include('../../functions.php');
	include('../../db-details.php');
	$connection = new Connection($u, $p, $db);
    $con = $connection->connect();

    $customer = new Customer($con);
    $customerslug = $customer->get_customer_from_event($_POST['event_slug']);

    include('../../customers/'.$customerslug.'/db-details.php');
    $CustomerConnection = new Connection($u, $p, $db);
    $con = $CustomerConnection->connect();

    $donationData = json_decode(stripslashes($_POST['donationData']));
    $donorData = json_decode(stripslashes($_POST['donorData']));

    $donationArray = get_object_vars($donationData);
    $donorArray = get_object_vars($donorData);
    $installation_id = $_POST['installation_id'];
    $donation_time = date('G').':'.date('i').':'.date('s');
    if(isset($donorArray['donor_anonymous']) &&  $donorArray['donor_anonymous']){
    	$donation_name = "Anonymous";
    }
    else {
    	if(isset($donorArray['donor_f_name']) && isset($donorArray['donor_l_name'])){
	    	$donation_name = $donorArray['donor_f_name'].' '.$donorArray['donor_l_name'];
	    }
	    else {
	    	$donation_name = '';
	    }
    }

    if(isset($donationArray['donation_amount'])){$donation_amount = $donationArray['donation_amount'];}
    else {$donation_amount = '';}

    if(isset($donorArray['donor_f_name'])){$donor_f_name = $donorArray['donor_f_name'];}
    else {$donor_f_name = '';}

    if(isset($donorArray['donor_l_name'])){$donor_l_name = $donorArray['donor_l_name'];}
    else {$donor_l_name = '';}

    if(isset($donorArray['donor_phone'])){$donor_phone = $donorArray['donor_phone'];}
    else {$donor_phone = '';}

    if(isset($donorArray['donor_email'])){$donor_email = $donorArray['donor_email'];}
	else {$donor_email = '';}

    if(isset($donorArray['donor_address_1'])){$donor_address_1 = $donorArray['donor_address_1'];}
    else {$donor_address_1 = '';}

    if(isset($donorArray['donor_address_2'])){$donor_address_2 = $donorArray['donor_address_2'];}
    else {$donor_address_2 = '';}

    if(isset($donorArray['donor_city'])){$donor_city = $donorArray['donor_city'];}
    else {$donor_city = '';}

    if(isset($donorArray['donor_postcode'])){$donor_postcode = $donorArray['donor_postcode'];}
    else {$donor_postcode = '';}

    if(isset($donorArray['donor_donation_period'])){$donor_donation_period = $donorArray['donor_donation_period'];}
    else {$donor_donation_period = '';}

    if(isset($donorArray['donor_giftaid'])){$donor_giftaid = $donorArray['donor_giftaid'];}
    else {$donor_giftaid = '';}

	if(!isset($donationArray['donation_id'])) {

    	mysqli_query($con,"INSERT INTO donations (
			donation_id,
			installation_id,
			donation_amount,
			donation_name,
			donation_time
		) VALUES (
			NULL,
			'$installation_id',
			'$donation_amount',
			'$donation_name',
			'$donation_time'
		);");
		$donation_id = mysqli_insert_id($con);

		mysqli_query($con,"INSERT INTO donors (
			donor_id,
			donor_f_name,
			donor_l_name,
			donor_phone,
			donor_email,
			donor_address_1,
			donor_address_2,
			donor_city,
			donor_postcode,
			donor_donation_period,
			donor_giftaid
		) VALUES (
			NULL, 
			'$donor_f_name',
			'$donor_l_name',
			'$donor_phone',
			'$donor_email',
			'$donor_address_1',
			'$donor_address_2',
			'$donor_city',
			'$donor_postcode',
			'$donor_donation_period',
			'$donor_giftaid'
		);");
		$donor_id = mysqli_insert_id($con);

		mysqli_query($con,"INSERT INTO donor_donations (
			donor_donation_id,
			donor_id,
			donation_id
		) VALUES (
			NULL, 
			$donor_id,
			$donation_id
		);");
    }
    else {
    	$donation_id = $donationArray['donation_id'];
    	$donor_id = $donorArray['donor_id'];

    	mysqli_query($con,"UPDATE donations SET
			donation_amount = '$donation_amount',
			donation_name = '$donation_name'
			WHERE donation_id = $donation_id
		");
    	mysqli_query($con,"UPDATE donors SET
			donor_f_name = '$donor_f_name',
			donor_l_name = '$donor_l_name',
			donor_phone = '$donor_phone',
			donor_email = '$donor_email',
			donor_address_1 = '$donor_address_1',
			donor_address_2 = '$donor_address_2',
			donor_city = '$donor_city',
			donor_postcode = '$donor_postcode',
			donor_donation_period = '$donor_donation_period',
			donor_giftaid = '$donor_giftaid'
			WHERE donor_id = $donor_id
		");
    }

    echo '
    	<input type="hidden" name="donation_id" value="'.$donation_id.'"/>
    	<input type="hidden" name="donor_id" value="'.$donor_id.'"/>
	';
?>