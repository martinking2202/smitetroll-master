<?php	
    include('../../functions.php');
    include('../../db-details.php');
    
    $connection = new Connection($u, $p, $db);
    $con = $connection->connect();

    $customer = new Customer($con);
    $customerslug = $customer->get_customer_from_event($_POST['event_slug']);

    include('../../customers/'.$customerslug.'/db-details.php');
    $CustomerConnection = new Connection($u, $p, $db);
    $con = $CustomerConnection->connect();

    $output = '';
    if($get_donations = mysqli_query($con, "SELECT * FROM donations")) {			        
        while ($donation = $get_donations->fetch_assoc()) {
        	$donation_amount = $donation['donation_amount'];

        	$output = $output + $donation_amount;
        }
    }
    echo $output;
?>