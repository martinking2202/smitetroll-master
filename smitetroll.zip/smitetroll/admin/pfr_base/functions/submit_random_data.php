<?php	
	include('../db-details.php');
	$mysqli= new mysqli("localhost","$u","$p","$db");
    $con=mysqli_connect("localhost","$u","$p","$db");

    function generateRandomString($length) {
	    $characters = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
	    $charactersLength = strlen($characters);
	    $randomString = '';
	    for ($i = 0; $i < $length; $i++) {
	        $randomString .= $characters[rand(0, $charactersLength - 1)];
	    }
	    return $randomString;
	}

	function generateRandomNumber($length) {
	    $characters = '1234567890';
	    $charactersLength = strlen($characters);
	    $randomString = '';
	    for ($i = 0; $i < $length; $i++) {
	        $randomString .= $characters[rand(0, $charactersLength - 1)];
	    }
	    return $randomString;
	}

	$donation_time = date('G').':'.date('i').':'.date('s');

    $anon = array('Yes','');
    $anonCalc = rand(0,1);

    $donPer = array(
    	'single',
    	'1 month',
    	'2 months',
    	'3 months',
    	'4 months',
    	'5 months',
    	'6 months',
    	'7 months',
    	'8 months',
    	'9 months',
    	'10 months',
    	'11 months',
    	'12 months',
    	'',
	);
    $donPerCalc = rand(0,13);

    $giftCalc = rand(0,1);

    if($anon[$anonCalc]){
    	$donation_name = "Anonymous";
    }
    else {
    	$donation_name = generateRandomString(6).' '.generateRandomString(10);
    }

    if(!$donPer[$donPerCalc]){
    	$donor_donation_period = rand(1,6).rand(1,9).' months';
    }
    else {
    	$donor_donation_period = $donPer[$donPerCalc];
    }

   	$donation_amount = generateRandomNumber(rand(2,3));
    $donor_f_name = generateRandomString(6);
    $donor_l_name = generateRandomString(10);
    $donor_phone = generateRandomNumber(11);
    $donor_email = generateRandomString(10).'@'.generateRandomString(8).'.com';
    $donor_address_1 = generateRandomString(15);
    $donor_address_2 = generateRandomString(15);
    $donor_city = generateRandomString(8);
    $donor_postcode = generateRandomString(6);
    $donor_giftaid = $anon[$giftCalc];

    echo $donation_amount.'||';
    echo $donor_f_name.'||';
    echo $donor_l_name.'||';
    echo $donor_phone.'||';
   	echo $donor_email.'||';
    echo $donor_address_1.'||';
    echo $donor_address_2.'||';
    echo $donor_city.'||';
    echo $donor_postcode.'||';
    echo $donor_giftaid;


	mysqli_query($con,"INSERT INTO donations (
		donation_id,
		donation_amount,
		donation_name,
		donation_time
	) VALUES (
		NULL, 
		'$donation_amount',
		'$donation_name',
		'$donation_time'
	);");
	$donation_id = mysqli_insert_id($con);

	mysqli_query($con,"INSERT INTO donors (
		donor_id,
		donor_f_name,
		donor_l_name,
		donor_phone,
		donor_email,
		donor_address_1,
		donor_address_2,
		donor_city,
		donor_postcode,
		donor_donation_period,
		donor_giftaid
	) VALUES (
		NULL, 
		'$donor_f_name',
		'$donor_l_name',
		'$donor_phone',
		'$donor_email',
		'$donor_address_1',
		'$donor_address_2',
		'$donor_city',
		'$donor_postcode',
		'$donor_donation_period',
		'$donor_giftaid'
	);");
	$donor_id = mysqli_insert_id($con);

	mysqli_query($con,"INSERT INTO donor_donations (
		donor_donation_id,
		donor_id,
		donation_id
	) VALUES (
		NULL, 
		$donor_id,
		$donation_id
	);");

?>