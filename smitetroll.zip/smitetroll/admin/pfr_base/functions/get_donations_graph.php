<?php	
	include('../db-details.php');
	$mysqli= new mysqli("localhost","$u","$p","$db");
    $con=mysqli_connect("localhost","$u","$p","$db");

    $output = '';
    if($get_donations = mysqli_query($con, "SELECT * FROM donations ORDER BY donation_id ASC;")) {			        
        while ($donation = $get_donations->fetch_assoc()) {
        	$donation_id = $donation['donation_id'];
        	$donation_name = $donation['donation_name'];
        	$donation_amount = $donation['donation_amount'];
        	$donation_time = $donation['donation_time'];
        	
        	$output .= '
        		<div class="bar">
        			<input name="donation_time" type="hidden" value="'.$donation_time.'"/>
					<input name="donation_amount" type="hidden" value="'.$donation_amount.'"/>
					<input name="donation_id" type="hidden" value="'.$donation_id.'"/>
				</div>
			';
        }
    }
    echo $output;
?>