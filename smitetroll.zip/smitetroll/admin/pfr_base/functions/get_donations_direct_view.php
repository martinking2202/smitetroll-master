<?php	
	include('../db-details.php');
	$mysqli= new mysqli("localhost","$u","$p","$db");
    $con=mysqli_connect("localhost","$u","$p","$db");

    $donation_info = array(
		'donation_id' => '',
		'donor_id' => '',
	    'donation_name' => '',
	    'donation_amount' => '',
	    'donor_f_name' => '',
	    'donor_l_name' => '',
	    'donor_phone' => '',
	    'donor_email' => '',
	    'donor_address_1' => '',
	    'donor_address_2' => '',
	    'donor_city' => '',
	    'donor_postcode' => '',
	    'donor_donation_period' => '',
	    'donor_giftaid' => ''
	);

	if($get_donor_info = mysqli_query($con, "SELECT * FROM donors;")) {			        
	    while ($get_donor = $get_donor_info->fetch_assoc()) {
	    	$donorId = $get_donor['donor_id'];
	    	$donation_info['donor_id'] = $get_donor['donor_id'];
	    	$donation_info['donor_f_name'] = $get_donor['donor_f_name'];
		    $donation_info['donor_l_name'] = $get_donor['donor_l_name'];
		    $donation_info['donor_phone'] = $get_donor['donor_phone'];
		    $donation_info['donor_email'] = $get_donor['donor_email'];
		    $donation_info['donor_address_1'] = $get_donor['donor_address_1'];
		    $donation_info['donor_address_2'] = $get_donor['donor_address_2'];
		    $donation_info['donor_city'] = $get_donor['donor_city'];
		    $donation_info['donor_postcode'] = $get_donor['donor_postcode'];
		    $donation_info['donor_donation_period'] = $get_donor['donor_donation_period'];
		    $donation_info['donor_giftaid'] = $get_donor['donor_giftaid'];
		    if($get_donation_id = mysqli_query($con, "SELECT * FROM donor_donations WHERE donor_id = $donorId ;")) {			        
		        while ($get_donation = $get_donation_id->fetch_assoc()) {
		        	$donation_id = $get_donation['donation_id'];
		        	if($get_donation = mysqli_query($con, "SELECT * FROM donations WHERE donation_id = $donation_id;")) {			        
		        		while ($donation = $get_donation->fetch_assoc()) {
		        			$donation_info['donation_id'] = $donation['donation_id'];
		        			$donation_info['donation_amount'] = $donation['donation_amount'];
				    		$donation_info['donation_name'] = $donation['donation_name'];
		        		}
		        	}
		        }
		    }
	?>
			<tr>
				<td>
					<input type="submit" value="Update" class="update_entry" name="update_entry"/>
					<input type="hidden" name="donor_id" value="<?php echo $donation_info['donor_id'];?>" />
					<input type="hidden" name="donation_id" value="<?php echo $donation_info['donation_id'];?>" />
				</td>
				<td>
					<input name="donor_f_name" value="<?php echo $donation_info['donor_f_name'];?>" type="text"/>
				</td>
				<td>
					<input name="donor_l_name" value="<?php echo $donation_info['donor_l_name'];?>" type="text"/>
				</td>
				<td>
					<input name="donor_phone" value="<?php echo $donation_info['donor_phone'];?>" type="text"/>
				</td>
				<td>
					<input name="donor_email" value="<?php echo $donation_info['donor_email'];?>" type="text"/>
				</td>
				<td>
					<input name="donor_address_1" value="<?php echo $donation_info['donor_address_1'];?>" type="text"/>
				</td>
				<td>
					<input name="donor_address_2" value="<?php echo $donation_info['donor_address_2'];?>" type="text"/>
				</td>
				<td>
					<input name="donor_city" value="<?php echo $donation_info['donor_city'];?>" type="text"/>
				</td>
				<td>
					<input name="donor_postcode" value="<?php echo $donation_info['donor_postcode'];?>" type="text"/>
				</td>
				<td>
					<input name="donor_donation_period" value="<?php echo $donation_info['donor_donation_period'];?>" type="text"/>
				</td>
				<td>
					<input name="donor_giftaid" value="<?php echo $donation_info['donor_giftaid'];?>" type="text"/>
				</td>
				<td>
					<input name="donation_amount" value="<?php echo $donation_info['donation_amount'];?>" type="text"/>
				</td>
				<td>
					<input name="donation_name" value="<?php echo $donation_info['donation_name'];?>" type="text"/>
				</td>
			</tr>
<?php
	    }
	}
?>