<?php	
	include('../db-details.php');
	$mysqli= new mysqli("localhost","$u","$p","$db");
    $con=mysqli_connect("localhost","$u","$p","$db");

    if(isset($_POST['lastDonor'])){
    	$donorId = $_POST['lastDonor'];

	    $donation_info = array(
	    	'donation_id' => '',
	    	'donor_id' => '',
		    'donation_name' => '',
		    'donation_amount' => '',
		    'donor_f_name' => '',
		    'donor_l_name' => '',
		    'donor_phone' => '',
		    'donor_email' => '',
		    'donor_address_1' => '',
		    'donor_address_2' => '',
		    'donor_city' => '',
		    'donor_postcode' => '',
		    'donor_donation_period' => '',
		    'donor_giftaid' => ''
	    );
	    if($get_donor_info = mysqli_query($con, "SELECT * FROM donors WHERE donor_id = $donorId;")) {			        
	        while ($get_donor = $get_donor_info->fetch_assoc()) {
	        	$donation_info['donor_id'] = $get_donor['donor_id'];
	        	$donation_info['donor_f_name'] = $get_donor['donor_f_name'];
			    $donation_info['donor_l_name'] = $get_donor['donor_l_name'];
			    $donation_info['donor_phone'] = $get_donor['donor_phone'];
			    $donation_info['donor_email'] = $get_donor['donor_email'];
			    $donation_info['donor_address_1'] = $get_donor['donor_address_1'];
			    $donation_info['donor_address_2'] = $get_donor['donor_address_2'];
			    $donation_info['donor_city'] = $get_donor['donor_city'];
			    $donation_info['donor_postcode'] = $get_donor['donor_postcode'];
			    $donation_info['donor_donation_period'] = $get_donor['donor_donation_period'];
			    $donation_info['donor_giftaid'] = $get_donor['donor_giftaid'];
	        }
	    }
    }
    else {
    	$donation_info = array(
	    	'donation_id' => '',
		    'donation_name' => '',
		    'donation_amount' => ''
	    );
    }
    $donation_id = $_POST['lastDonation'];
    
	if($get_donation = mysqli_query($con, "SELECT * FROM donations WHERE donation_id = $donation_id;")) {			        
		while ($donation = $get_donation->fetch_assoc()) {
			$donation_info['donation_id'] = $donation['donation_id'];
			$donation_info['donation_amount'] = $donation['donation_amount'];
    		$donation_info['donation_name'] = $donation['donation_name'];
		}
	}
           
    $json = json_encode($donation_info);

    echo $json;
?>