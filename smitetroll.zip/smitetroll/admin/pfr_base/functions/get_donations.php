<?php	
	include('../../functions.php');
    include('../../db-details.php');
    
    $connection = new Connection($u, $p, $db);
    $con = $connection->connect();

    $customer = new Customer($con);
    $customerslug = $customer->get_customer_from_event($_POST['event_slug']);

    include('../../customers/'.$customerslug.'/db-details.php');
    $CustomerConnection = new Connection($u, $p, $db);
    $con = $CustomerConnection->connect();

    $lastDonation = $_POST['lastDonation'];
    $output = '';
    if($get_donations = mysqli_query($con, "SELECT * FROM donations WHERE donation_id > $lastDonation ORDER BY donation_id DESC;")) {			        
        while ($donation = $get_donations->fetch_assoc()) {
        	$donation_id = $donation['donation_id'];
        	if($donation_id !== $lastDonation){
	        	$donation_name = $donation['donation_name'];
	        	$donation_amount = $donation['donation_amount'];

	        	$output .= '
	        		<div class="donation">
						<h4>'.$donation_name.'</h4>
						<h3 class="donation_amount">£'.$donation_amount.'</h3>
						<span class="message">Thank You</span>
						<input name="donation_id" type="hidden" value="'.$donation_id.'"/>
					</div>
				';
			}
        }
    }
    echo $output;
?>