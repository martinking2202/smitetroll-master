<?php	
	include('db-details.php');
	$mysqli= new mysqli("localhost","$u","$p","$db");
    $con=mysqli_connect("localhost","$u","$p","$db");

	header('Content-Type: application/csv');
    header('Content-Disposition: attachment; filename=summary.csv');

    $output = fopen('php://output', 'w');

    fputcsv($output, 
        array(
            'First Name',
            'Last Name',
            'Phone',
            'Email',
            'Address 1',
            'Address 2',
            'City',
            'Postcode',
            'Donation Period',
            'GiftAid',
            'Donation Name',
            'Donation Amount'
        )
    );

	if($get_donor_info = mysqli_query($con, "SELECT * FROM donors;")) {			        
        while ($get_donor = $get_donor_info->fetch_assoc()) {
        	$donation_info = array();
        	$donorId = $get_donor['donor_id'];
        	$donation_info[0] = $get_donor['donor_f_name'];
		    $donation_info[1] = $get_donor['donor_l_name'];
		    $donation_info[2] = $get_donor['donor_phone'];
		    $donation_info[3] = $get_donor['donor_email'];
		    $donation_info[4] = $get_donor['donor_address_1'];
		    $donation_info[5] = $get_donor['donor_address_2'];
		    $donation_info[6] = $get_donor['donor_city'];
		    $donation_info[7] = $get_donor['donor_postcode'];
		    $donation_info[8] = $get_donor['donor_donation_period'];
		    $donation_info[9] = $get_donor['donor_giftaid'];

		    if($get_donation_id = mysqli_query($con, "SELECT * FROM donor_donations WHERE donor_id = $donorId ;")) {			        
		        while ($get_donation = $get_donation_id->fetch_assoc()) {
		        	$donation_id = $get_donation['donation_id'];
		        	if($get_donation = mysqli_query($con, "SELECT * FROM donations WHERE donation_id = $donation_id;")) {			        
		        		while ($donation = $get_donation->fetch_assoc()) {
				    		$donation_info[10] = $donation['donation_name'];
				    		$donation_info[11] = $donation['donation_amount'];
		        		}
		        	}
		        }
		    }
		    fputcsv($output , $donation_info);
        }
    }
    fpassthru($output);