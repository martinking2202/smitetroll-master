<?php
	include('functions.php');
	include('db-details.php');
	$connection = new Connection($u, $p, $db);
    $mainCon = $connection->connect();

    $customer = new Customer($mainCon);
    $customerslug = $customer->get_customer_from_event($_GET['event_name']);

    include('customers/'.$customerslug.'/db-details.php');
    $CustomerConnection = new Connection($u, $p, $db);
    $con = $CustomerConnection->connect();

    $currentEvent = new Event($mainCon, $customerslug, $_GET['event_name']);
    $installation_id = $currentEvent->get_installation_id($con, $_GET['event_name']);

    $uploadImage = '';
    if(isset($_FILES["event_logo"]) && $_FILES["event_logo"]["name"]){
    	$uploadImage = $currentEvent->upload_event_logo($con, $customerslug, $installation_id);
    	redirect('../../admin/events.php?updated='.$installation_id.'&action=logo');
    }
?>
<!DOCTYPE html>
<html>
	<head>
		<meta charset="UTF-8" />
		<meta name="viewport" content="width=device-width" />
		<title></title>
<?php
		include_once('pfr_base/css/style.php');
?>
		<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>
<?php
		include_once('pfr_base/js/js.php');
?>
	</head>
	<body>
		<header>
			
		</header>
		<div id="main">
			<?php echo $uploadImage;?>
			<form id="form_upload" class="normal_sub" action="" method="post" enctype="multipart/form-data">
			    Select image to upload:
			    <input type="file" name="event_logo" id="event_logo">
			    <input type="submit" value="Upload Image" name="submit">
			</form>
		</div>
	</body>
</html>