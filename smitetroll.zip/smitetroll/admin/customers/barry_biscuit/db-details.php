<?php
$db = 'pfr_barry_biscuit';
$u = 'barry_biscuit';
$p = '1RHeBIj35Aq';
?>