<?php
	include('functions.php');
	include('db-details.php');
	$connection = new Connection($u, $p, $db);
    $mainCon = $connection->connect();

    $customer = new Customer($mainCon);
    $customerslug = $customer->get_customer_from_event($_GET['event_name']);

    include('customers/'.$customerslug.'/db-details.php');
    $CustomerConnection = new Connection($u, $p, $db);
    $con = $CustomerConnection->connect();

    $currentEvent = new Event($mainCon, $customerslug, $_GET['event_name']);
    $installation_id = $currentEvent->get_installation_id($con, $_GET['event_name']);

	$eventTarget = $currentEvent->get_installation_setting($con, 'event_target', $installation_id);
	$eventLogo = $currentEvent->get_installation_setting($con, 'event_logo', $installation_id);
	$eventAdditionalArea = $currentEvent->get_installation_setting($con, 'event_additional_area', $installation_id);
	$eventCharityName = $currentEvent->get_installation_setting($con, 'event_charity_name', $installation_id);
	$eventCharityAddress = $currentEvent->get_installation_setting($con, 'event_charity_address', $installation_id);
	$eventWebsite = $currentEvent->get_installation_setting($con, 'event_website', $installation_id);
	$eventEmail = $currentEvent->get_installation_setting($con, 'event_email', $installation_id);
	$eventCharityNo = $currentEvent->get_installation_setting($con, 'event_charity_no', $installation_id);
?>
<!DOCTYPE html>
<html>
	<head>
		<meta charset="UTF-8" />
		<meta name="viewport" content="width=device-width" />
		<title>PowerFundraiser</title>
<?php
		include_once('pfr_base/css/style.php');
?>
		<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>
<?php
		include_once('pfr_base/js/js.php');
?>
	</head>
	<body>
		<header>

		</header>
		<div id="content" class="visual">
			<section id ="sect1">
				<div id="logo">
					<img src="<?php echo $eventLogo;?>"/>
				</div>
				<p>PowerFundRaiser Live Donate</p>
				<div id="live_totals">
					<div class="row" data-total-type="total_raised">
						<span>Live Total:</span>
						<strong>£0</strong>
					</div>
					<div class="row" data-total-type="total_remaining">
						<span>Still Required:</span>
						<strong>£0</strong>
					</div>
				</div>
				<div id="details">
<?php
					if($eventCharityName || $eventCharityAddress || $eventWebsite || $eventCharityNo){
?>
						<h3>Charity Details</h3>
						<p>
							<b><?php echo $eventCharityName;?></b>
						</p>
						<p>
<?php
							if($eventCharityAddress){
?>
								Address:<br/>
<?php
							}
?>
							<?php echo nl2br($eventCharityAddress);?>
						</p>
						<p>
							<?php echo $eventWebsite;?>
							<?php echo $eventEmail;?>
						</p>
						<p>
<?php
							if($eventCharityNo){
?>
								Registered Charity: <?php echo $eventCharityNo;?>
<?php
							}
?>
						</p>	
<?php
					}
?>
				</div>
			</section>
			<section id ="sect2">
				<?php echo $eventAdditionalArea;?>
			</section>
			<section id ="sect3">
				<h4>Live Donations</h4>
				<div class="overlay"></div>
				<div id="live_feed">
					<div class="donation">
						<input name="donation_id" type="hidden" value="0"/>
					</div>
				</div>
			</section>
			<section id ="sect4">
				<h4>Todays Target</h4>
				<div id="live_progress">
					<div class="target">
						<h4>£<?php echo $eventTarget;?></h4>
					</div>
					<div class="progress_bar">
						<div class="overlay">
						</div>
						<div class="bar first"></div>
					</div>
				</div>
			</section>