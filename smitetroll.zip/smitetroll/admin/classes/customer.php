<?php
	class Customer {
        // Creating some properties (variables tied to an object)
        
        public $connection;
        
        // Assigning the values
        public function __construct($connection) {
	          $this->connection = $connection;
        }
        
        // Creating a method (function tied to an object)
        public function create_db($customer) {
        	$customer_slug = $customer;
        	$db = 'pfr_'.$customer_slug;
        	$pw = randomPassword(11);
            $createDB = mysqli_query($this->connection, "CREATE DATABASE $db");
            $createUser = mysqli_query($this->connection, "CREATE USER '".$customer_slug."'@'localhost' IDENTIFIED BY '".$pw."';");
            $userPerms = mysqli_query($this->connection, "GRANT ALL ON pfr_".$customer_slug.".* TO '".$customer_slug."'@'localhost';");

            $newConnection = new Connection($customer_slug, $pw, $db);

            $customerConnect = $newConnection->connect();

            // Name of the file
            $filename = 'event.sql';
            // Temporary variable, used to store current query
            $templine = '';
            // Read in entire file
            $lines = file($filename);
            // Loop through each line
            foreach ($lines as $line){
                // Skip it if it's a comment
                if (substr($line, 0, 2) == '--' || $line == '')
                    continue;

                // Add this line to the current segment
                $templine .= $line;
                // If it has a semicolon at the end, it's the end of the query
                if (substr(trim($line), -1, 1) == ';'){
                    // Perform the query
                    mysqli_query($customerConnect, $templine) or print('Error performing query \'<strong>' . $templine . '\': ' . mysqli_error($customerConnect) . '<br /><br />');
                    // Reset temp variable to empty
                    $templine = '';
                }
            }
            return $pw;
        }

        public function create_file_structure($customer, $pw){
            if(!file_exists('customers/'.$customer)){
            	mkdir('customers/'.$customer, 0755, true);
            }
            $myfile = fopen("customers/".$customer."/db-details.php", "w") or die("Unable to open file!");
			$txt = "<?php\n\$db = 'pfr_$customer';\n\$u = '$customer';\n\$p = '$pw';\n?>"
			;
			fwrite($myfile, $txt);
			fclose($myfile);
        }

        public function setup_customer($customerName, $customer){
            $connection = $this->connection;
            $setupCustomer = mysqli_query(
                $connection,"INSERT INTO customers (
                    customer_id,
                    customer_name,
                    customer_slug
                )
                VALUES (
                    NULL,
                    '$customerName',
                    '$customer'
                )"
            );
            $customer_id = $connection->insert_id;
            return $customer_id;
        }

        public function get_customer_from_event($event_slug){

            $getInstallation = mysqli_query($this->connection,"SELECT * FROM installations WHERE installation_name = '$event_slug'");
            $row = mysqli_fetch_assoc($getInstallation);
            $install_id = $row['installation_id'];


            $getCustomerInstallation = mysqli_query($this->connection,"SELECT * FROM customer_installations WHERE installation_id = '$install_id'");
            $row = mysqli_fetch_assoc($getCustomerInstallation);
            $customer_id = $row['customer_id'];

            $getCustomer = mysqli_query($this->connection,"SELECT * FROM customers WHERE customer_id = '$customer_id'");
            $row = mysqli_fetch_assoc($getCustomer);
            $customer_slug = $row['customer_slug'];

            return $customer_slug;
        }  

        public function get_customer($customer){

            $getCustomer = mysqli_query($this->connection,"SELECT * FROM customers WHERE customer_id = $customer");
            $row = mysqli_fetch_assoc($getCustomer);

            $retCustomer = array(
                'id' => $row['customer_id'],
                'name' => $row['customer_name'],
                'slug' => $row['customer_slug'],
                'credits' => $row['customer_credits']
            );

            return $retCustomer;
        } 

        public function get_events($con) {
            $sql = "SELECT * FROM installations";
            $return = array();
            if ($result = mysqli_query($con, $sql)) {
                while ($row = mysqli_fetch_assoc($result)) {
                    $installation_id = $row['installation_id'];
                    $installation_name = $row['installation_name'];
                    $retInstall = array(
                        'id' => $installation_id,
                        'name' => $installation_name
                    );
                    array_push($return, $retInstall);
                }
            }
            return $return;
        }

        public function get_credits($customer_id){
            $getCustomer = mysqli_query($this->connection, "SELECT * FROM customers WHERE customer_id = $customer_id");
            if($getCustomer){
                $row = mysqli_fetch_assoc($getCustomer);
                $credits = $row['customer_credits'];

                return $credits;
            }
            else {
                return false;
            }
        }

        public function spend_credit($customer_id){
            $getCustomer = mysqli_query($this->connection,"SELECT * FROM customers WHERE customer_id = $customer_id");
            $row = mysqli_fetch_assoc($getCustomer);
            $credits = $row['customer_credits'];

            if($credits > 0){
                $credits--;
            }
            else {
                return false;
            }

            $updateCredits = mysqli_query($this->connection,"UPDATE customers SET
                customer_credits = '$credits'
                WHERE customer_id = '$customer_id'
            ");

            return true;
        }

        public function add_credits($customer_id, $credits){
            $getCustomer = mysqli_query($this->connection,"SELECT * FROM customers WHERE customer_id = $customer_id");
            $row = mysqli_fetch_assoc($getCustomer);
            $current_credits = $row['customer_credits'];
            $new_credits = $current_credits + $credits;

            $updateCredits = mysqli_query($this->connection,"UPDATE customers SET
                customer_credits = '$new_credits'
                WHERE customer_id = '$customer_id'
            ");

            return true;
        }

        public function add_credit_plan($customer_id, $plan, $credits, $purchasedate, $start, $end){
            $addPlan = mysqli_query($this->connection,"INSERT INTO customer_plan_purchases (
                    plan_purchase_id,
                    customer_id,
                    plan_type,
                    credits_purchased,
                    plan_purchase_date,
                    plan_start_date,
                    plan_end_date
                )
                VALUES (
                    NULL,
                    '$customer_id',
                    '$plan',
                    '$credits',
                    '$purchasedate',
                    '$start',
                    '$end'
                )"
            );
           
            return true;
        }

        public function get_purchases($customer_id) {
            $sql = "SELECT * FROM customer_plan_purchases wHERE customer_id = $customer_id";
            $return = array();
            if ($result = mysqli_query($this->connection, $sql)) {
                while ($row = mysqli_fetch_assoc($result)) {
                    $plan_type = $row['plan_type'];
                    $credits_purchased = $row['credits_purchased'];
                    $plan_purchase_date = $row['plan_purchase_date'];
                    $plan_start_date = $row['plan_start_date'];
                    $plan_end_date = $row['plan_end_date'];

                    $planRow = array(
                        'plan_type' => $plan_type,
                        'credits_purchased' => $credits_purchased,
                        'plan_purchase_date' => $plan_purchase_date,
                        'plan_start_date' => $plan_start_date,
                        'plan_end_date' => $plan_end_date
                    );
                    array_push($return, $planRow);
                }
            }
            return $return;
        }
  	}
?>