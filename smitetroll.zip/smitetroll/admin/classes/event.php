<?php
  class Event {
        // Creating some properties (variables tied to an object)
        public $connection;
        public $customer;
        public $event;

        // Assigning the values
        public function __construct($connection, $customer, $event) {
            $this->connection = $connection;
            $this->customer = $customer;
            $this->event = $event;
        }
        
        // Creating a method (function tied to an object)
        public function setup_customer_db($con, $customer, $event) {
            $setupInstallation = mysqli_query(
                $con,"INSERT INTO installations (
                    installation_id,
                    installation_name
                )
                VALUES (
                    NULL,
                    '$event'
                )"
            );

            $event_id = $con->insert_id;
            mysqli_close($con);
            return $event_id;
        }

        public function setup_main_db($con, $customer_slug, $event_slug) {
            $mainSetupInstallation = mysqli_query(
                $con,"INSERT INTO installations (
                    installation_id,
                    installation_name
                )
                VALUES (
                    NULL,
                    '$event_slug'
                )"
            );

            $event_id = $con->insert_id;

            $getCustomerID = mysqli_query($this->connection,"SELECT * FROM customers WHERE customer_slug = '$customer_slug'");
            $row = mysqli_fetch_assoc($getCustomerID);
            $customer_id = $row['customer_id'];

            $mainSetupCustomerInstallation = mysqli_query(
                $con,"INSERT INTO customer_installations (
                    customer_installation_id,
                    customer_id,
                    installation_id
                )
                VALUES (
                    NULL,
                    '$customer_id',
                    '$event_id'
                )"
            );
            mysqli_close($con);
        }

        public function create_file_structure($customer, $event){
            xcopy('pfr_base', "customers/".$customer.'/'.$event);
        }

        public function get_installation_id($con, $event_slug) {
            $getInstallID = mysqli_query($con,"SELECT * FROM installations WHERE installation_name = '$event_slug'");
            $row = mysqli_fetch_assoc($getInstallID);
            $installation_id = $row['installation_id'];

            return $installation_id;
        }

         public function get_installation_customisation($con, $customisation, $installation_id) {
            $customisationValue = '';
            if($getCustomisation = mysqli_query($con,"SELECT * FROM customisations WHERE installation_id = $installation_id AND customisation_name = '$customisation'")){
                $row = mysqli_fetch_assoc($getCustomisation);
                $customisationValue = $row['customisation_value'];
            }
            return $customisationValue;
        }

        public function get_installation_setting($con, $setting, $installation_id) {
            $settingValue = '';
            if($getSetting = mysqli_query($con,"SELECT * FROM system WHERE installation_id = $installation_id AND option_name = '$setting'")){
                $row = mysqli_fetch_assoc($getSetting);
                $settingValue = $row['option_value'];
            }
            return $settingValue;
        }

        public function upload_event_logo($con, $customer, $installation_id){
            $target_dir = 'customers/'.$customer.'/';
            $target_file = $target_dir . basename($_FILES["event_logo"]["name"]);
            $uploadOk = 1;
            $return = '';
            $imageFileType = pathinfo($target_file,PATHINFO_EXTENSION);
            // Check if image file is a actual image or fake image
            if(isset($_POST["submit"])) {
                $check = getimagesize($_FILES["event_logo"]["tmp_name"]);
                if($check !== false) {
                    $return .= "File is an image - " . $check["mime"] . ".<br/>";
                    $uploadOk = 1;
                } else {
                    $return .= "File is not an image.<br/>";
                    $uploadOk = 0;
                }
            }
            // Check if file already exists
            if (file_exists($target_file)) {
                $return .= "Sorry, file already exists.<br/>";
                $uploadOk = 0;
            }
            // Check file size
            if ($_FILES["event_logo"]["size"] > 500000) {
                $return .= "Sorry, your file is too large.<br/>";
                $uploadOk = 0;
            }
            // Allow certain file formats
            if($imageFileType != "jpg" && $imageFileType != "png" && $imageFileType != "jpeg"
            && $imageFileType != "gif" ) {
                $return .= "Sorry, only JPG, JPEG, PNG & GIF files are allowed.<br/>";
                $uploadOk = 0;
            }
            // Check if $uploadOk is set to 0 by an error
            if ($uploadOk == 0) {
                $return .= "Sorry, your file was not uploaded.<br/>";
            // if everything is ok, try to upload file
            } else {
                if (move_uploaded_file($_FILES["event_logo"]["tmp_name"], $target_file)) {
                    $return .= "The file ". basename( $_FILES["event_logo"]["name"]). " has been uploaded.<br/>";
                } else {
                    $return .= "Sorry, there was an error uploading your file.<br/>";
                }
            }
            $overwrite = 0;
            $optionID = 0;
            $currentPage = $_SERVER["PHP_SELF"];
            $mainDir = substr($currentPage, 0, strrpos($currentPage, '/'));
            $lookupLogo = mysqli_query($con, "SELECT * FROM system WHERE option_name = 'event_logo' AND installation_id = $installation_id;");

            if($lookupLogo->num_rows){
                $row = mysqli_fetch_assoc($lookupLogo);
                $eventLogo = $row['option_value'];
                $logoName = substr(substr($eventLogo, strrpos($currentPage, '/')), 1);
                $optionID = $row['system_id'];
                $overwrite = 1;
                unlink($logoName);
            }
            if($overwrite){
                $addLogo = mysqli_query($con,"UPDATE system SET
                    option_value = '$mainDir/$target_file'
                    WHERE system_id = '$optionID'
                ");
            }
            else {
                $addLogo = mysqli_query(
                    $con,"INSERT INTO system (
                        system_id,
                        option_name,
                        option_value,
                        installation_id
                    )
                    VALUES (
                        NULL,
                        'event_logo',
                        '$mainDir/$target_file',
                        '$installation_id'
                    )"
                );
            }
            $return .= mysqli_error($con);
            return $return;
        }

        public function add_event_customisation($con, $customer, $customisation, $customisationValue, $installation_id){
            $lookupCustomisation = mysqli_query($con, "SELECT * FROM customisations WHERE customisation_name = '$customisation' AND installation_id = $installation_id;");
            $overwrite = 0;
            if($lookupCustomisation && $lookupCustomisation->num_rows){
                $row = mysqli_fetch_assoc($lookupCustomisation);
                $customisationID = $row['customisation_id'];
                $overwrite = 1;
            }
            if($overwrite){
                $addCustomisation = mysqli_query($con,"UPDATE customisations SET
                    customisation_value = '$customisationValue'
                    WHERE customisation_id = '$customisationID'
                ");
            }
            else {
                $addCustomisation = mysqli_query(
                    $con,"INSERT INTO customisations (
                        customisation_id,
                        customisation_name,
                        customisation_value,
                        installation_id
                    )
                    VALUES (
                        NULL,
                        '$customisation',
                        '$customisationValue',
                        '$installation_id'
                    )"
                );
            }
        }

        public function add_event_system_option($con, $customer, $systemOption, $systemOptionValue, $installation_id){
            $lookupOption = mysqli_query($con, "SELECT * FROM system WHERE option_name = '$systemOption' AND installation_id = $installation_id;");
            $overwrite = 0;
            $systemOptionValue = $con->real_escape_string($systemOptionValue);
            if($lookupOption && $lookupOption->num_rows){
                $row = mysqli_fetch_assoc($lookupOption);
                $systemID = $row['system_id'];
                $overwrite = 1;
            }
            if($overwrite){
                $addSystemOption = mysqli_query($con,"UPDATE system SET
                    option_value = '$systemOptionValue'
                    WHERE system_id = '$systemID'
                ");
            }
            else {
                $addSystemOption = mysqli_query(
                    $con,"INSERT INTO system (
                        system_id,
                        option_name,
                        option_value,
                        installation_id
                    )
                    VALUES (
                        NULL,
                        '$systemOption',
                        '$systemOptionValue',
                        '$installation_id'
                    )"
                );
            }
            return mysqli_error($con);
        }
    }
?>