<?php

$db = 'pfr_new';
$u = 'root';
$p = '';

$access = 'b786';

?>