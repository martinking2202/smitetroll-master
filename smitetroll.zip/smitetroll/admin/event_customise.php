<?php
	include('functions.php');
	include('db-details.php');
	$connection = new Connection($u, $p, $db);
    $mainCon = $connection->connect();

    $customer = new Customer($mainCon);
    $customerslug = $customer->get_customer_from_event($_GET['event_name']);

    include('customers/'.$customerslug.'/db-details.php');
    $CustomerConnection = new Connection($u, $p, $db);
    $con = $CustomerConnection->connect();

    $currentEvent = new Event($mainCon, $customerslug, $_GET['event_name']);
    $installation_id = $currentEvent->get_installation_id($con, $_GET['event_name']);


    if(isset($_POST['bg_colour']) && $_POST['bg_colour']) $currentEvent->add_event_customisation($con, $customerslug, 'bg_colour', $_POST['bg_colour'], $installation_id);
	if(isset($_POST['button_bg_colour']) && $_POST['button_bg_colour']) $currentEvent->add_event_customisation($con, $customerslug, 'button_bg_colour', $_POST['button_bg_colour'], $installation_id);
	if(isset($_POST['button_text_colour']) && $_POST['button_text_colour']) $currentEvent->add_event_customisation($con, $customerslug, 'button_text_colour', $_POST['button_text_colour'], $installation_id);
	if(isset($_POST['value_colour']) && $_POST['value_colour']) $currentEvent->add_event_customisation($con, $customerslug, 'value_colour', $_POST['value_colour'], $installation_id);
	if(isset($_POST['value_box_colour']) && $_POST['value_box_colour']) $currentEvent->add_event_customisation($con, $customerslug, 'value_box_colour', $_POST['value_box_colour'], $installation_id);
	if(isset($_POST['sect_1_bg_colour']) && $_POST['sect_1_bg_colour']) $currentEvent->add_event_customisation($con, $customerslug, 'sect_1_bg_colour', $_POST['sect_1_bg_colour'], $installation_id);
	if(isset($_POST['sect_2_bg_colour']) && $_POST['sect_2_bg_colour']) $currentEvent->add_event_customisation($con, $customerslug, 'sect_2_bg_colour', $_POST['sect_2_bg_colour'], $installation_id);
	if(isset($_POST['sect_3_bg_colour']) && $_POST['sect_3_bg_colour']) $currentEvent->add_event_customisation($con, $customerslug, 'sect_3_bg_colour', $_POST['sect_3_bg_colour'], $installation_id);
	if(isset($_POST['sect_4_bg_colour']) && $_POST['sect_4_bg_colour']) $currentEvent->add_event_customisation($con, $customerslug, 'sect_4_bg_colour', $_POST['sect_4_bg_colour'], $installation_id);
	if(isset($_POST['bar_colour']) && $_POST['bar_colour']) $currentEvent->add_event_customisation($con, $customerslug, 'bar_colour', $_POST['bar_colour'], $installation_id);
	if(isset($_POST['add_bar_colour']) && $_POST['add_bar_colour']) $currentEvent->add_event_customisation($con, $customerslug, 'add_bar_colour', $_POST['add_bar_colour'], $installation_id);
	if(isset($_POST['add_bar_opacity']) && $_POST['add_bar_opacity']) $currentEvent->add_event_customisation($con, $customerslug, 'add_bar_opacity', $_POST['add_bar_opacity'], $installation_id);
    
    if(
    	isset($_POST['add_bar_opacity']) ||
    	isset($_POST['add_bar_colour']) ||
    	isset($_POST['bar_colour']) ||
    	isset($_POST['sect_4_bg_colour']) ||
    	isset($_POST['sect_3_bg_colour']) ||
    	isset($_POST['sect_2_bg_colour']) ||
    	isset($_POST['sect_1_bg_colour']) ||
    	isset($_POST['value_box_colour']) ||
    	isset($_POST['value_colour']) ||
    	isset($_POST['button_text_colour']) ||
    	isset($_POST['button_bg_colour']) ||
    	isset($_POST['bg_colour'])
	)
		redirect('../../admin/events.php?updated='.$installation_id.'&action=customise');
?>
<!DOCTYPE html>
<html>
	<head>
		<meta charset="UTF-8" />
		<meta name="viewport" content="width=device-width" />
		<title></title>
<?php
		include_once('pfr_base/css/style.php');
?>
		<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>
<?php
		include_once('pfr_base/js/js.php');
?>
	</head>
	<body>
		<header>
			
		</header>
		<div id="main">
			<form id="form_customise" class="normal_sub" action="" method="post" enctype="multipart/form-data">
				<label for="bg_colour">Main Background Colour</label>
			    <input type="color" name="bg_colour" id="bg_colour"/>
			    <label for="button_bg_colour">Button Background Colour</label>
			    <input type="color" name="button_bg_colour" id="button_bg_colour"/>
			    <label for="button_text_colour">Button Text Colour</label>
			    <input type="color" name="button_text_colour" id="button_text_colour"/>
			    <label for="value_colour">Totals Colour</label>
			    <input type="color" name="value_colour" id="value_colour"/>
			    <label for="value_box_colour">Totals Box Background Colour</label>
			    <input type="color" name="value_box_colour" id="value_box_colour"/>
			    <label for="sect_1_bg_colour">Section 1 Background Colour</label>
			    <input type="color" name="sect_1_bg_colour" id="sect_1_bg_colour"/>
			    <label for="sect_2_bg_colour">Section 2 Background Colour</label>
			    <input type="color" name="sect_2_bg_colour" id="sect_2_bg_colour"/>
			    <label for="sect_3_bg_colour">Section 3 Background Colour</label>
			    <input type="color" name="sect_3_bg_colour" id="sect_3_bg_colour"/>
			    <label for="sect_4_bg_colour">Section 4 Background Colour</label>
			    <input type="color" name="sect_4_bg_colour" id="sect_4_bg_colour"/>
			    <label for="bar_colour">Bar Colour</label>
			    <input type="color" name="bar_colour" id="bar_colour"/>
			    <label for="add_bar_colour">Additional Bar Colour</label>
			    <input type="color" name="add_bar_colour" id="add_bar_colour"/>
			    <label for="add_bar_opacity">Additional Bar Opacity</label>
			    <input type="text" name="add_bar_opacity" id="add_bar_opacity"/>
			    <input type="submit" value="Submit Customisations" name="submit">
			</form>
		</div>
	</body>
</html>