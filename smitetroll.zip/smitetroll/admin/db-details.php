<?php
$u = 'root';
$p = '';
$db = 'pfr_admin';
?>