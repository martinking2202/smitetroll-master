-- phpMyAdmin SQL Dump
-- version 4.3.11
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Apr 01, 2016 at 06:51 PM
-- Server version: 5.6.24
-- PHP Version: 5.6.8

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `pfr_barry_biscuit`
--

-- --------------------------------------------------------

--
-- Table structure for table `customisations`
--

CREATE TABLE IF NOT EXISTS `customisations` (
  `customisation_id` int(11) NOT NULL,
  `customisation_name` varchar(250) NOT NULL,
  `customisation_value` varchar(10000) NOT NULL,
  `installation_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `donations`
--

CREATE TABLE IF NOT EXISTS `donations` (
  `donation_id` int(11) NOT NULL,
  `installation_id` int(11) NOT NULL,
  `donation_amount` decimal(10,2) NOT NULL,
  `donation_name` varchar(200) NOT NULL,
  `donation_time` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `donors`
--

CREATE TABLE IF NOT EXISTS `donors` (
  `donor_id` int(11) NOT NULL,
  `donor_f_name` varchar(100) DEFAULT NULL,
  `donor_l_name` varchar(100) DEFAULT NULL,
  `donor_phone` varchar(20) DEFAULT NULL,
  `donor_email` varchar(100) DEFAULT NULL,
  `donor_address_1` varchar(100) DEFAULT NULL,
  `donor_address_2` varchar(100) DEFAULT NULL,
  `donor_city` varchar(50) DEFAULT NULL,
  `donor_postcode` varchar(20) DEFAULT NULL,
  `donor_donation_period` varchar(20) DEFAULT NULL,
  `donor_giftaid` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `donor_donations`
--

CREATE TABLE IF NOT EXISTS `donor_donations` (
  `donor_donation_id` int(11) NOT NULL,
  `donor_id` int(11) NOT NULL,
  `donation_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `installations`
--

CREATE TABLE IF NOT EXISTS `installations` (
  `installation_id` int(11) NOT NULL,
  `installation_name` varchar(250) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `system`
--

CREATE TABLE IF NOT EXISTS `system` (
  `system_id` int(11) NOT NULL,
  `option_name` varchar(100) NOT NULL,
  `option_value` varchar(1000) NOT NULL,
  `installation_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `customisations`
--
ALTER TABLE `customisations`
  ADD PRIMARY KEY (`customisation_id`);

--
-- Indexes for table `donations`
--
ALTER TABLE `donations`
  ADD PRIMARY KEY (`donation_id`);

--
-- Indexes for table `donors`
--
ALTER TABLE `donors`
  ADD PRIMARY KEY (`donor_id`);

--
-- Indexes for table `donor_donations`
--
ALTER TABLE `donor_donations`
  ADD PRIMARY KEY (`donor_donation_id`);

--
-- Indexes for table `installations`
--
ALTER TABLE `installations`
  ADD PRIMARY KEY (`installation_id`);

--
-- Indexes for table `system`
--
ALTER TABLE `system`
  ADD PRIMARY KEY (`system_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `customisations`
--
ALTER TABLE `customisations`
  MODIFY `customisation_id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `donations`
--
ALTER TABLE `donations`
  MODIFY `donation_id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `donors`
--
ALTER TABLE `donors`
  MODIFY `donor_id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `donor_donations`
--
ALTER TABLE `donor_donations`
  MODIFY `donor_donation_id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `installations`
--
ALTER TABLE `installations`
  MODIFY `installation_id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `system`
--
ALTER TABLE `system`
  MODIFY `system_id` int(11) NOT NULL AUTO_INCREMENT;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
