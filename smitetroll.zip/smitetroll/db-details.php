<?php
$u = 'smitetroll';
$p = '$yg@GkXyS.J0';
$db = 'smitetroll';
?>