<?php
	session_start();

	include('classes/connection.php');
	include('classes/god.php');
	include('classes/item.php');
//	include('classes/relic.php');