<?php
$u = 'root';
$p = '';
$db = 'smitetroll';
?>