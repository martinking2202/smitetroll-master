<?php
	include('functions.php');
	include('db-details.php');
	$connection = new Connection($u, $p, $db);
	$con = $connection->connect();

	$god = new God($con);
	$rand_god = $god->get_random_god();
	$item = new Item($con);

	$excluded_items = array();
?>
<!DOCTYPE html>
<html>
	<head>
		<meta charset="UTF-8" />
		<meta name="viewport" content="width=device-width" />
		<title></title>
		<link rel="stylesheet" type="text/css" href="css/style.css" />
		<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>
		<script type="text/javascript" src="js/js.js"></script>
	</head>
	<body>
		<header>
			
		</header>
		<div id="main">
			<div id="god">
<?php
					echo $rand_god['name'];
?>
				<div class="god">

				</div>
				<div class="items">
					<div class="item">
<?php
						$item1 = $item->get_random_item('', 'boots-'.$rand_god['type']);
						echo $item1['name'];
						$excluded_items[] = $item1['id'];
?>
					</div>
					<div class="item">
<?php
						$item2 = $item->get_random_item($excluded_items, $rand_god['type']);
						echo $item2['name'];
						$excluded_items[] = $item2['id'];
?>
					</div>
					<div class="item">
<?php
						$item3 = $item->get_random_item($excluded_items, $rand_god['type']);
						echo $item3['name'];
						$excluded_items[] = $item3['id'];
?>
					</div>
					<div class="item">
<?php
						$item4 = $item->get_random_item($excluded_items, $rand_god['type']);
						echo $item4['name'];
						$excluded_items[] = $item4['id'];
?>
					</div>
					<div class="item">
<?php
						$item5 = $item->get_random_item($excluded_items, $rand_god['type']);
						echo $item5['name'];
						$excluded_items[] = $item5['id'];
?>
					</div>
					<div class="item">
<?php
						$item6 = $item->get_random_item($excluded_items, $rand_god['type']);
						echo $item6['name'];
						$excluded_items[] = $item6['id'];
?>
					</div>
				</div>
			</div>
		</div>
	</body>
</html>